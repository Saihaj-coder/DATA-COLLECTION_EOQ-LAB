PROC Format;
   Value DISTF
          -9  = "Not ascertained"
          1  = "Yes"
          2  = "No"
   ;
   Value DISTSIZF
          1  = "Less than 2,500"
          2  = "2,500-9,999"
          3  = "10,000 or more"
   ;
   Value FLAGF
          0  = "Not imputed"
          1  = "Imputed"
   ;
   Value LEVELF
          1  = "Elementary"
          2  = "Secondary"
          3  = "Combined"
   ;
   Value MINSTF
          1  = "Less than 6%"
          2  = "6% to 20%"
          3  = "21% to 49%"
          4  = "50% or more"
   ;
   Value POVSTF
          1  = "Less than 35 percent"
          2  = "35 to 49 percent"
          3  = "50 to 74 percent"
          4  = "75 percent or more"
   ;
   Value Q10AF
          1  = "Less than 1 hour"
          2  = "1 to 8 hours"
          3  = "2 to 5 days"
          4  = "1 to 3 weeks"
          5  = "A month or more"
   ;
   Value Q10BF
          1  = "Less than 1 hour"
          2  = "1 to 8 hours"
          3  = "2 to 5 days"
          4  = "1 to 3 weeks"
          5  = "A month or more"
   ;
   Value Q10CF
          1  = "Less than 1 hour"
          2  = "1 to 8 hours"
          3  = "2 to 5 days"
          4  = "1 to 3 weeks"
          5  = "A month or more"
   ;
   Value Q10DF
          1  = "Less than 1 hour"
          2  = "1 to 8 hours"
          3  = "2 to 5 days"
          4  = "1 to 3 weeks"
          5  = "A month or more"
   ;
   Value Q11F
          1  = "Yes"
          2  = "No"
   ;
   Value Q12ACL1F
          1  = "Not at all"
          2  = "Minor extent"
          3  = "Moderate extent"
          4  = "Major extent"
   ;
   Value Q12ACL2F
          1  = "Not at all"
          2  = "Minor extent"
          3  = "Moderate extent"
          4  = "Major extent"
   ;
   Value Q12BCL1F
          1  = "Not at all"
          2  = "Minor extent"
          3  = "Moderate extent"
          4  = "Major extent"
   ;
   Value Q12BCL2F
          1  = "Not at all"
          2  = "Minor extent"
          3  = "Moderate extent"
          4  = "Major extent"
   ;
   Value Q12CCL1F
          1  = "Not at all"
          2  = "Minor extent"
          3  = "Moderate extent"
          4  = "Major extent"
   ;
   Value Q12CCL2F
          1  = "Not at all"
          2  = "Minor extent"
          3  = "Moderate extent"
          4  = "Major extent"
   ;
   Value Q12DCL1F
          1  = "Not at all"
          2  = "Minor extent"
          3  = "Moderate extent"
          4  = "Major extent"
   ;
   Value Q12DCL2F
          1  = "Not at all"
          2  = "Minor extent"
          3  = "Moderate extent"
          4  = "Major extent"
   ;
   Value Q12ECL1F
          1  = "Not at all"
          2  = "Minor extent"
          3  = "Moderate extent"
          4  = "Major extent"
   ;
   Value Q12ECL2F
          1  = "Not at all"
          2  = "Minor extent"
          3  = "Moderate extent"
          4  = "Major extent"
   ;
   Value Q12FCL1F
          1  = "Not at all"
          2  = "Minor extent"
          3  = "Moderate extent"
          4  = "Major extent"
   ;
   Value Q12FCL2F
          1  = "Not at all"
          2  = "Minor extent"
          3  = "Moderate extent"
          4  = "Major extent"
   ;
   Value Q12GCL1F
          1  = "Not at all"
          2  = "Minor extent"
          3  = "Moderate extent"
          4  = "Major extent"
   ;
   Value Q12GCL2F
          1  = "Not at all"
          2  = "Minor extent"
          3  = "Moderate extent"
          4  = "Major extent"
   ;
   Value Q12HCL1F
          1  = "Not at all"
          2  = "Minor extent"
          3  = "Moderate extent"
          4  = "Major extent"
   ;
   Value Q12HCL2F
          1  = "Not at all"
          2  = "Minor extent"
          3  = "Moderate extent"
          4  = "Major extent"
   ;
   Value Q12ICL1F
          1  = "Not at all"
          2  = "Minor extent"
          3  = "Moderate extent"
          4  = "Major extent"
   ;
   Value Q12ICL2F
          1  = "Not at all"
          2  = "Minor extent"
          3  = "Moderate extent"
          4  = "Major extent"
   ;
   Value Q13AF
          1  = "Strongly disagree"
          2  = "Somewhat disagree"
          3  = "Somewhat agree"
          4  = "Strongly agree"
   ;
   Value Q13BF
          1  = "Strongly disagree"
          2  = "Somewhat disagree"
          3  = "Somewhat agree"
          4  = "Strongly agree"
   ;
   Value Q13CF
          1  = "Strongly disagree"
          2  = "Somewhat disagree"
          3  = "Somewhat agree"
          4  = "Strongly agree"
   ;
   Value Q13DF
          1  = "Strongly disagree"
          2  = "Somewhat disagree"
          3  = "Somewhat agree"
          4  = "Strongly agree"
   ;
   Value Q13EF
          1  = "Strongly disagree"
          2  = "Somewhat disagree"
          3  = "Somewhat agree"
          4  = "Strongly agree"
   ;
   Value Q13FF
          1  = "Strongly disagree"
          2  = "Somewhat disagree"
          3  = "Somewhat agree"
          4  = "Strongly agree"
   ;
   Value Q13GF
          1  = "Strongly disagree"
          2  = "Somewhat disagree"
          3  = "Somewhat agree"
          4  = "Strongly agree"
   ;
   Value Q13HF
          1  = "Strongly disagree"
          2  = "Somewhat disagree"
          3  = "Somewhat agree"
          4  = "Strongly agree"
   ;
   Value Q13IF
          1  = "Strongly disagree"
          2  = "Somewhat disagree"
          3  = "Somewhat agree"
          4  = "Strongly agree"
   ;
   Value Q13JF
          1  = "Strongly disagree"
          2  = "Somewhat disagree"
          3  = "Somewhat agree"
          4  = "Strongly agree"
   ;
   Value Q5AF
          1  = "Yes"
          2  = "No"
   ;
   Value Q5BF
          1  = "Yes"
          2  = "No"
   ;
   Value Q5CF
          1  = "Yes"
          2  = "No"
   ;
   Value Q5DF
          1  = "Yes"
          2  = "No"
   ;
   Value Q5EF
          1  = "Yes"
          2  = "No"
   ;
   Value Q5FF
          1  = "Yes"
          2  = "No"
   ;
   Value Q5GF
          1  = "Yes"
          2  = "No"
   ;
   Value Q5HF
          1  = "Yes"
          2  = "No"
   ;
   Value Q8F
          1  = "No wireless network access of any kind"
          2  = "Only wireless connections from laptops to carts"
          3  = "Wireless is available in part of the school"
          4  = "Wireless is available in the whole school"
   ;
   Value Q9AF
          1  = "Yes"
          2  = "No"
   ;
   Value Q9BF
          1  = "Yes"
          2  = "No"
   ;
   Value Q9CF
          1  = "Yes"
          2  = "No"
   ;
   Value Q9DF
          1  = "Yes"
          2  = "No"
   ;
   Value Q9EF
          1  = "Yes"
          2  = "No"
   ;
   Value Q9FF
          1  = "Yes"
          2  = "No"
   ;
   Value Q9GF
          1  = "Yes"
          2  = "No"
   ;
   Value Q9HF
          1  = "Yes"
          2  = "No"
   ;
   Value REGION
          1  = "Northeast"
          2  = "Southeast"
          3  = "Central"
          4  = "West"
   ;
   Value SIZ92F
          1  = "Less than 300"
          2  = "300 to 999"
          3  = "1000 or more"
   ;
   Value URB92F
          1  = "City"
          2  = "Suburban"
          3  = "Town"
          4  = "Rural"
   ;
RUN;
