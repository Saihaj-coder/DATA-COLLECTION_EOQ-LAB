PROC Format;
   Value FLAGF
          0  = "Not imputed"
          1  = "Imputed"
   ;
   Value METROF
          1  = "URBAN"
          2  = "SUBURBAN"
          3  = "RURAL"
   ;
   Value POVF
          -9  = "Not ascertained"
          1  = "LESS THAN 10 PERCENT"
          2  = "10 TO 19 PERCENT"
          3  = "20 PERCENT OR MORE"
   ;
   Value Q10F
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q12AF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
          3  = "Don�t know"
   ;
   Value Q12BF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
          3  = "Don�t know"
   ;
   Value Q12CF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
          3  = "Don�t know"
   ;
   Value Q13AF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q13BF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q13CF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q13DF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q13EF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q14F
          -8  = "Inapplicable"
          1  = "Synchronous Internet"
          2  = "Asynchronous Internet"
          3  = "Two-way interactive video"
          4  = "One-way prerecorded video"
          5  = "Other technologies"
   ;
   Value Q15F
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q16AF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q16BF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q16CF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q17AF
          -8  = "Inapplicable"
          1  = "Yes, for all students"
          2  = "Yes, for some students"
          3  = "No"
   ;
   Value Q17BF
          -8  = "Inapplicable"
          1  = "Yes, for all students"
          2  = "Yes, for some students"
          3  = "No"
   ;
   Value Q17CF
          -8  = "Inapplicable"
          1  = "Yes, for all students"
          2  = "Yes, for some students"
          3  = "No"
   ;
   Value Q18F
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
          3  = "Don�t know"
   ;
   Value Q19F
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q2F
          1  = "Yes"
          2  = "No"
   ;
   Value Q6AF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
          3  = "Don�t know"
   ;
   Value Q6BF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
          3  = "Don�t know"
   ;
   Value Q6CF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
          3  = "Don�t know"
   ;
   Value Q6DF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
          3  = "Don�t know"
   ;
   Value Q6EF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
          3  = "Don�t know"
   ;
   Value Q6FF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
          3  = "Don�t know"
   ;
   Value Q6GF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
          3  = "Don�t know"
   ;
   Value Q6HF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
          3  = "Don�t know"
   ;
   Value Q6IF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
          3  = "Don�t know"
   ;
   Value Q6JF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
          3  = "Don�t know"
   ;
   Value Q6KF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
          3  = "Don�t know"
   ;
   Value Q6LF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
          3  = "Don�t know"
   ;
   Value Q7F
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q9AF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
          3  = "Don�t know"
   ;
   Value Q9BF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
          3  = "Don�t know"
   ;
   Value Q9CF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
          3  = "Don�t know"
   ;
   Value Q9DF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
          3  = "Don�t know"
   ;
   Value Q9EF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
          3  = "Don�t know"
   ;
   Value REGIONF
          1  = "NORTHEAST"
          2  = "SOUTHEAST"
          3  = "CENTRAL"
          4  = "WEST"
   ;
   Value SIZEF
          -9  = "Not ascertained"
          1  = "LESS THAN 2500"
          2  = "2500 TO 9999"
          3  = "10000 OR MORE"
   ;
RUN;
