*****************************************************************************************;
*       PROGRAM: STFIS081b_SAS.sas                                                      *;
*          NOTE: 1) This program reads in the State Fiscal tab-delimited text data      *;
*                   file.                                                               *;
*                2) To create a permanent SAS data set, add a LIBNAME statement and     *;
*                   add the LIBNAME to the DATA statement.                              *;
*                3) Modify the path in the INFILE statement below to point to the       *;
*                   location of the text data file.                                     *;
*                4) Refer to the record layout file for detailed description of the     *;
*                   data elements, variable and value labels                            *;
*   PROVIDED BY: National Center for Education Statistics                               *;
*   LAST UPDATED: March 3, 2011                                                         *;
*****************************************************************************************;
      data stfis081b;
      %let _EFIERR_ = 0; /* set the ERROR detection macro variable */
	infile 'G:\Public Use\Survey Data\CCD\State Fiscal (NPEFS)\NPEFS08\version 1b\stfis081b.txt' 
            delimiter='09'x MISSOVER DSD lrecl=32767 firstobs=2 ;

         informat SURVYEAR 12.;
         informat FIPS $2. ;
         informat STABR $2. ;
         informat STNAME $25. ;
         informat R1A 12. ;
         informat R1B 12. ;
         informat R1C 12. ;
         informat R1D 12. ;
         informat R1E 12. ;
         informat R1F 12. ;
         informat R1G 12. ;
         informat R1H 12. ;
         informat R1I 12. ;
         informat R1J 12. ;
         informat R1K 12. ;
         informat R1L  12. ;
         informat R1M  12. ;
         informat R1N  12. ;
         informat STR1 12. ;
         informat R2   12. ;
         informat R3  12. ;
         informat R4A 12. ;
         informat R4B 12. ;
         informat R4C 12. ;
         informat R4D 12. ;
         informat STR4 12. ;
         informat R5  12. ;
         informat TR  12. ;
         informat E11 12. ;
         informat E12 12. ;
         informat E13 12. ;
         informat E14 12. ;
         informat E15 12. ;
         informat E16 12. ;
         informat E17 12. ;
         informat E18 12. ;
         informat STE1 12. ;
         informat E11A 12. ;
         informat E11B 12. ;
         informat E11C 12. ;
         informat E11D 12. ;
         informat E2   12. ;
         informat E212 12. ;
         informat E213 12. ;
         informat E214 12. ;
         informat E215 12. ;
         informat E216 12. ;
         informat E217 12. ;
         informat E218 12. ;
         informat TE21 12. ;
         informat E222 12. ;
         informat E223 12. ;
         informat E224 12. ;
         informat E225 12. ;
         informat E226 12. ;
         informat E227 12. ;
         informat E228 12. ;
         informat TE22 12. ;
         informat E232 12. ;
         informat E233 12. ;
         informat E234 12. ;
         informat E235 12. ;
         informat E236 12. ;
         informat E237 12. ;
         informat E238 12. ;
         informat TE23 12. ;
         informat E242 12. ;
         informat E243 12. ;
         informat E244 12. ;
         informat E245 12. ;
         informat E246 12. ;
         informat E247 12. ;
         informat E248 12. ;
         informat TE24 12. ;
         informat E252 12. ;
         informat E253 12. ;
         informat E254 12. ;
         informat E255 12. ;
         informat E256 12. ;
         informat E257 12. ;
         informat E258 12. ;
         informat TE25 12. ;
         informat E262 12. ;
         informat E263 12. ;
         informat E264 12. ;
         informat E265 12. ;
         informat E266 12. ;
         informat E267 12. ;
         informat E268 12. ;
         informat TE26 12. ;
         informat STE22 12. ;
         informat STE23 12. ;
         informat STE24 12. ;
         informat STE25 12. ;
         informat STE26 12. ;
         informat STE27 12. ;
         informat STE28 12. ;
         informat STE2T 12. ;
         informat E3A11 12. ;
         informat E3A12 12. ;
         informat E3A13 12. ;
         informat E3A14 12. ;
         informat E3A2 12. ;
         informat E3A16 12. ;
         informat E3A1 12. ;
         informat E3B11 12. ;
         informat E3B12 12. ;
         informat E3B13 12. ;
         informat E3B14 12. ;
         informat E3B2 12. ;
         informat E3B16 12. ;
         informat E3B1 12. ;
         informat STE3 12. ;
         informat E4A1 12. ;
         informat E4A2 12. ;
         informat E4B1 12. ;
         informat E4B2 12. ;
         informat E4C1 12. ;
         informat E4C2 12. ;
         informat E4D 12. ;
         informat E4E1 12. ;
         informat E4E2 12. ;
         informat STE4 12. ;
         informat TE5 12. ;
         informat E61 12. ;
         informat E62 12. ;
         informat E63 12. ;
         informat STE6 12. ;
         informat E7A1 12. ;
         informat E7A2 12. ;
         informat STE7 12. ;
         informat E81 12. ;
         informat E82 12. ;
         informat E9A 12. ;
         informat E9B 12. ;
         informat E9C 12. ;
         informat E9D 12. ;
         informat E91 12. ;
         informat STE9 12. ;
         informat TE10 12. ;
         informat TE11 12. ;
         informat X12C 12. ;
         informat X12D 12. ;
         informat X12E 12. ;
         informat X12F 12. ;
         informat TX12 12. ;
         informat NCE13 12. ;
         informat ADA 12. ;
         informat A14A 12. ;
         informat A14B 12. ;
         informat PPE15 12. ;
         informat MEMBR07 12. ;
         informat IR1A $1. ;
         informat IR1B $1. ;
         informat IR1C $1. ;
         informat IR1D $1. ;
         informat IR1E $1. ;
         informat IR1F $1. ;
         informat IR1G $1. ;
         informat IR1H $1. ;
         informat IR1I $1. ;
         informat IR1J $1. ;
         informat IR1K $1. ;
         informat IR1L $1. ;
         informat IR1M $1. ;
         informat IR1N $1. ;
         informat ISTR1 $1. ;
         informat IR2 $1. ;
         informat IR3 $1. ;
         informat IR4A $1. ;
         informat IR4B $1. ;
         informat IR4C $1. ;
         informat IR4D $1. ;
         informat ISTR4 $1. ;
         informat IR5 $1. ;
         informat ITR $1. ;
         informat IE11 $1. ;
         informat IE12 $1. ;
         informat IE13 $1. ;
         informat IE14 $1. ;
         informat IE15 $1. ;
         informat IE16 $1. ;
         informat IE17 $1. ;
         informat IE18 $1. ;
         informat ISTE1 $1. ;
         informat IE11A $1. ;
         informat IE11B $1. ;
         informat IE11C $1. ;
         informat IE11D $1. ;
         informat IE2 $1. ;
         informat IE212 $1. ;
         informat IE213 $1. ;
         informat IE214 $1. ;
         informat IE215 $1. ;
         informat IE216 $1. ;
         informat IE217 $1. ;
         informat IE218 $1. ;
         informat ITE21 $1. ;
         informat IE222 $1. ;
         informat IE223 $1. ;
         informat IE224 $1. ;
         informat IE225 $1. ;
         informat IE226 $1. ;
         informat IE227 $1. ;
         informat IE228 $1. ;
         informat ITE22 $1. ;
         informat IE232 $1. ;
         informat IE233 $1. ;
         informat IE234 $1. ;
         informat IE235 $1. ;
         informat IE236 $1. ;
         informat IE237 $1. ;
         informat IE238 $1. ;
         informat ITE23 $1. ;
         informat IE242 $1. ;
         informat IE243 $1. ;
         informat IE244 $1. ;
         informat IE245 $1. ;
         informat IE246 $1. ;
         informat IE247 $1. ;
         informat IE248 $1. ;
         informat ITE24 $1. ;
         informat IE252 $1. ;
         informat IE253 $1. ;
         informat IE254 $1. ;
         informat IE255 $1. ;
         informat IE256 $1. ;
         informat IE257 $1. ;
         informat IE258 $1. ;
         informat ITE25 $1. ;
         informat IE262 $1. ;
         informat IE263 $1. ;
         informat IE264 $1. ;
         informat IE265 $1. ;
         informat IE266 $1. ;
         informat IE267 $1. ;
         informat IE268 $1. ;
         informat ITE26 $1. ;
         informat ISTE22 $1. ;
         informat ISTE23 $1. ;
         informat ISTE24 $1. ;
         informat ISTE25 $1. ;
         informat ISTE26 $1. ;
         informat ISTE27 $1. ;
         informat ISTE28 $1. ;
         informat ISTE2T $1. ;
         informat IE3A11 $1. ;
         informat IE3A12 $1. ;
         informat IE3A13 $1. ;
         informat IE3A14 $1. ;
         informat IE3A2 $1. ;
         informat IE3A16 $1. ;
         informat IE3A1 $1. ;
         informat IE3B11 $1. ;
         informat IE3B12 $1. ;
         informat IE3B13 $1. ;
         informat IE3B14 $1. ;
         informat IE3B2 $1. ;
         informat IE3B16 $1. ;
         informat IE3B1 $1. ;
         informat ISTE3 $1. ;
         informat IE4A1 $1. ;
         informat IE4A2 $1. ;
         informat IE4B1 $1. ;
         informat IE4B2 $1. ;
         informat IE4C1 $1. ;
         informat IE4C2 $1. ;
         informat IE4D $1. ;
         informat IE4E1 $1. ;
         informat IE4E2 $1. ;
         informat ISTE4 $1. ;
         informat ITE5 $1. ;
         informat IE61 $1. ;
         informat IE62 $1. ;
         informat IE63 $1. ;
         informat ISTE6 $1. ;
         informat IE7A1 $1. ;
         informat IE7A2 $1. ;
         informat ISTE7 $1. ;
         informat IE81 $1. ;
         informat IE82 $1. ;
         informat IE9A $1. ;
         informat IE9B $1. ;
         informat IE9C $1. ;
         informat IE9D $1. ;
         informat IE91 $1. ;
         informat ISTE9 $1. ;
         informat ITE10 $1. ;
         informat ITE11 $1. ;
         informat IX12C $1. ;
         informat IX12D $1. ;
         informat IX12E $1. ;
         informat IX12F $1. ;
         informat ITX12 $1. ;
         informat INCE13 $1. ;
         informat IADA $1. ;
         informat IA14A $1. ;
         informat IA14B $1. ;
         informat IPPE15 $1. ;
         informat IMEMBR07 $1. ;

         format SURVYEAR 12. ;
         format FIPS $2. ;
         format STABR $2. ;
         format STNAME $25. ;
         format R1A 12. ;
         format R1B 24. ;
         format R1C 12. ;
         format R1D 12. ;
         format R1E 12. ;
         format R1F 12. ;
         format R1G 12. ;
         format R1H 12. ;
         format R1I 12. ;
         format R1J 12. ;
         format R1K 12. ;
         format R1L 12. ;
         format R1M 12. ;
         format R1N 12. ;
         format STR1 12. ;
         format R2 12. ;
         format R3 12. ;
         format R4A 12. ;
         format R4B 12. ;
         format R4C 12. ;
         format R4D 12. ;
         format STR4 12. ;
         format R5 12. ;
         format TR 12. ;
         format E11 12. ;
         format E12 12. ;
         format E13 12. ;
         format E14 12. ;
         format E15 12. ;
         format E16 12. ;
         format E17 12. ;
         format E18 12. ;
         format STE1 12. ;
         format E11A 12. ;
         format E11B 12. ;
         format E11C 12. ;
         format E11D 12. ;
         format E2 12. ;
         format E212 12. ;
         format E213 12. ;
         format E214 12. ;
         format E215 12. ;
         format E216 12. ;
         format E217 12. ;
         format E218 12. ;
         format TE21 12. ;
         format E222 12. ;
         format E223 12. ;
         format E224 12. ;
         format E225 12. ;
         format E226 12. ;
         format E227 12. ;
         format E228 12. ;
         format TE22 12. ;
         format E232 12. ;
         format E233 12. ;
         format E234 12. ;
         format E235 12. ;
         format E236 12. ;
         format E237 12. ;
         format E238 12. ;
         format TE23 12. ;
         format E242 12. ;
         format E243 12. ;
         format E244 12. ;
         format E245 12. ;
         format E246 12. ;
         format E247 12. ;
         format E248 12. ;
         format TE24 12. ;
         format E252 12. ;
         format E253 12. ;
         format E254 12. ;
         format E255 12. ;
         format E256 12. ;
         format E257 12. ;
         format E258 12. ;
         format TE25 12. ;
         format E262 12. ;
         format E263 12. ;
         format E264 12. ;
         format E265 12. ;
         format E266 12. ;
         format E267 12. ;
         format E268 12. ;
         format TE26 12. ;
         format STE22 12. ;
         format STE23 12. ;
         format STE24 12. ;
         format STE25 12. ;
         format STE26 12. ;
         format STE27 12. ;
         format STE28 12. ;
         format STE2T 12. ;
         format E3A11 12. ;
         format E3A12 12. ;
         format E3A13 12. ;
         format E3A14 12. ;
         format E3A2 12. ;
         format E3A16 12. ;
         format E3A1 12. ;
         format E3B11 12. ;
         format E3B12 12. ;
         format E3B13 12. ;
         format E3B14 12. ;
         format E3B2 12. ;
         format E3B16 12. ;
         format E3B1 12. ;
         format STE3 12. ;
         format E4A1 12. ;
         format E4A2 12. ;
         format E4B1 12. ;
         format E4B2 12. ;
         format E4C1 12. ;
         format E4C2 12. ;
         format E4D 12. ;
         format E4E1 12. ;
         format E4E2 12. ;
         format STE4 12. ;
         format TE5 12. ;
         format E61 12. ;
         format E62 12. ;
         format E63 12. ;
         format STE6 12. ;
         format E7A1 12. ;
         format E7A2 12. ;
         format STE7 12. ;
         format E81 12. ;
         format E82 12. ;
         format E9A 12. ;
         format E9B 12. ;
         format E9C 12. ;
         format E9D 12. ;
         format E91 12. ;
         format STE9 12. ;
         format TE10 12. ;
         format TE11 12. ;
         format X12C 12. ;
         format X12D 12. ;
         format X12E 12. ;
         format X12F 12. ;
         format TX12 12. ;
         format NCE13 12. ;
         format ADA 12. ;
         format A14A 12. ;
         format A14B 12. ;
         format PPE15 12. ;
         format MEMBR07 12. ;

         format IR1A $1. ;
         format IR1B $1. ;
         format IR1C $1. ;
         format IR1D $1. ;
         format IR1E $1. ;
         format IR1F $1. ;
         format IR1G $1. ;
         format IR1H $1. ;
         format IR1I $1. ;
         format IR1J $1. ;
         format IR1K $1. ;
         format IR1L $1. ;
         format IR1M $1. ;
         format IR1N $1. ;
         format ISTR1 $1. ;
         format IR2 $1. ;
         format IR3 $1. ;
         format IR4A $1. ;
         format IR4B $1. ;
         format IR4C $1. ;
         format IR4D $1. ;
         format ISTR4 $1. ;
         format IR5 $1. ;
         format ITR $1. ;
         format IE11 $1. ;
         format IE12 $1. ;
         format IE13 $1. ;
         format IE14 $1. ;
         format IE15 $1. ;
         format IE16 $1. ;
         format IE17 $1. ;
         format IE18 $1. ;
         format ISTE1 $1. ;
         format IE11A $1. ;
         format IE11B $1. ;
         format IE11C $1. ;
         format IE11D $1. ;
         format IE2 $1. ;
         format IE212 $1. ;
         format IE213 $1. ;
         format IE214 $1. ;
         format IE215 $1. ;
         format IE216 $1. ;
         format IE217 $1. ;
         format IE218 $1. ;
         format ITE21 $1. ;
         format IE222 $1. ;
         format IE223 $1. ;
         format IE224 $1. ;
         format IE225 $1. ;
         format IE226 $1. ;
         format IE227 $1. ;
         format IE228 $1. ;
         format ITE22 $1. ;
         format IE232 $1. ;
         format IE233 $1. ;
         format IE234 $1. ;
         format IE235 $1. ;
         format IE236 $1. ;
         format IE237 $1. ;
         format IE238 $1. ;
         format ITE23 $1. ;
         format IE242 $1. ;
         format IE243 $1. ;
         format IE244 $1. ;
         format IE245 $1. ;
         format IE246 $1. ;
         format IE247 $1. ;
         format IE248 $1. ;
         format ITE24 $1. ;
         format IE252 $1. ;
         format IE253 $1. ;
         format IE254 $1. ;
         format IE255 $1. ;
         format IE256 $1. ;
         format IE257 $1. ;
         format IE258 $1. ;
         format ITE25 $1. ;
         format IE262 $1. ;
         format IE263 $1. ;
         format IE264 $1. ;
         format IE265 $1. ;
         format IE266 $1. ;
         format IE267 $1. ;
         format IE268 $1. ;
         format ITE26 $1. ;
         format ISTE22 $1. ;
         format ISTE23 $1. ;
         format ISTE24 $1. ;
         format ISTE25 $1. ;
         format ISTE26 $1. ;
         format ISTE27 $1. ;
         format ISTE28 $1. ;
         format ISTE2T $1. ;
         format IE3A11 $1. ;
         format IE3A12 $1. ;
         format IE3A13 $1. ;
         format IE3A14 $1. ;
         format IE3A2 $1. ;
         format IE3A16 $1. ;
         format IE3A1 $1. ;
         format IE3B11 $1. ;
         format IE3B12 $1. ;
         format IE3B13 $1. ;
         format IE3B14 $1. ;
         format IE3B2 $1. ;
         format IE3B16 $1. ;
         format IE3B1 $1. ;
         format ISTE3 $1. ;
         format IE4A1 $1. ;
         format IE4A2 $1. ;
         format IE4B1 $1. ;
         format IE4B2 $1. ;
         format IE4C1 $1. ;
         format IE4C2 $1. ;
         format IE4D $1. ;
         format IE4E1 $1. ;
         format IE4E2 $1. ;
         format ISTE4 $1. ;
         format ITE5 $1. ;
         format IE61 $1. ;
         format IE62 $1. ;
         format IE63 $1. ;
         format ISTE6 $1. ;
         format IE7A1 $1. ;
         format IE7A2 $1. ;
         format ISTE7 $1. ;
         format IE81 $1. ;
         format IE82 $1. ;
         format IE9A $1. ;
         format IE9B $1. ;
         format IE9C $1. ;
         format IE9D $1. ;
         format IE91 $1. ;
         format ISTE9 $1. ;
         format ITE10 $1. ;
         format ITE11 $1. ;
         format IX12C $1. ;
         format IX12D $1. ;
         format IX12E $1. ;
         format IX12F $1. ;
         format ITX12 $1. ;
         format INCE13 $1. ;
         format IADA $1. ;
         format IA14A $1. ;
         format IA14B $1. ;
         format IPPE15 $1. ;
         format IMEMBR07 $1. ;
      input
                  SURVYEAR
                  FIPS $
                  STABR $
                  STNAME $
                  R1A
                  R1B
                  R1C
                  R1D
                  R1E
                  R1F
                  R1G
                  R1H
                  R1I
                  R1J
                  R1K
                  R1L
                  R1M
                  R1N
                  STR1
                  R2
                  R3
                  R4A
                  R4B
                  R4C
                  R4D
                  STR4
                  R5
                  TR
                  E11
                  E12
                  E13
                  E14
                  E15
                  E16
                  E17
                  E18
                  STE1
                  E11A
                  E11B
                  E11C
                  E11D
                  E2
                  E212
                  E213
                  E214
                  E215
                  E216
                  E217
                  E218
                  TE21
                  E222
                  E223
                  E224
                  E225
                  E226
                  E227
                  E228
                  TE22
                  E232
                  E233
                  E234
                  E235
                  E236
                  E237
                  E238
                  TE23
                  E242
                  E243
                  E244
                  E245
                  E246
                  E247
                  E248
                  TE24
                  E252
                  E253
                  E254
                  E255
                  E256
                  E257
                  E258
                  TE25
                  E262
                  E263
                  E264
                  E265
                  E266
                  E267
                  E268
                  TE26
                  STE22
                  STE23
                  STE24
                  STE25
                  STE26
                  STE27
                  STE28
                  STE2T
                  E3A11
                  E3A12
                  E3A13
                  E3A14
                  E3A2
                  E3A16
                  E3A1
                  E3B11
                  E3B12
                  E3B13
                  E3B14
                  E3B2
                  E3B16
                  E3B1
                  STE3
                  E4A1
                  E4A2
                  E4B1
                  E4B2
                  E4C1
                  E4C2
                  E4D
                  E4E1
                  E4E2
                  STE4
                  TE5
                  E61
                  E62
                  E63
                  STE6
                  E7A1
                  E7A2
                  STE7
                  E81
                  E82
                  E9A
                  E9B
                  E9C
                  E9D
                  E91
                  STE9
                  TE10
                  TE11
                  X12C
                  X12D
                  X12E
                  X12F
                  TX12
                  NCE13
                  ADA
                  A14A
                  A14B
                  PPE15
                  MEMBR07
                  IR1A $
                  IR1B $
                  IR1C $
                  IR1D $
                  IR1E $
                  IR1F $
                  IR1G $
                  IR1H $
                  IR1I $
                  IR1J $
                  IR1K $
                  IR1L $
                  IR1M $
                  IR1N $
                  ISTR1 $
                  IR2 $
                  IR3 $
                  IR4A $
                  IR4B $
                  IR4C $
                  IR4D $
                  ISTR4 $
                  IR5 $
                  ITR $
                  IE11 $
                  IE12 $
                  IE13 $
                  IE14 $
                  IE15 $
                  IE16 $
                  IE17 $
                  IE18 $
                  ISTE1 $
                  IE11A $
                  IE11B $
                  IE11C $
                  IE11D $
                  IE2 $
                  IE212 $
                  IE213 $
                  IE214 $
                  IE215 $
                  IE216 $
                  IE217 $
                  IE218 $
                  ITE21 $
                  IE222 $
                  IE223 $
                  IE224 $
                  IE225 $
                  IE226 $
                  IE227 $
                  IE228 $
                  ITE22 $
                  IE232 $
                  IE233 $
                  IE234 $
                  IE235 $
                  IE236 $
                  IE237 $
                  IE238 $
                  ITE23 $
                  IE242 $
                  IE243 $
                  IE244 $
                  IE245 $
                  IE246 $
                  IE247 $
                  IE248 $
                  ITE24 $
                  IE252 $
                  IE253 $
                  IE254 $
                  IE255 $
                  IE256 $
                  IE257 $
                  IE258 $
                  ITE25 $
                  IE262 $
                  IE263 $
                  IE264 $
                  IE265 $
                  IE266 $
                  IE267 $
                  IE268 $
                  ITE26 $
                  ISTE22 $
                  ISTE23 $
                  ISTE24 $
                  ISTE25 $
                  ISTE26 $
                  ISTE27 $
                  ISTE28 $
                  ISTE2T $
                  IE3A11 $
                  IE3A12 $
                  IE3A13 $
                  IE3A14 $
                  IE3A2 $
                  IE3A16 $
                  IE3A1 $
                  IE3B11 $
                  IE3B12 $
                  IE3B13 $
                  IE3B14 $
                  IE3B2 $
                  IE3B16 $
                  IE3B1 $
                  ISTE3 $
                  IE4A1 $
                  IE4A2 $
                  IE4B1 $
                  IE4B2 $
                  IE4C1 $
                  IE4C2 $
                  IE4D $
                  IE4E1 $
                  IE4E2 $
                  ISTE4 $
                  ITE5 $
                  IE61 $
                  IE62 $
                  IE63 $
                  ISTE6 $
                  IE7A1 $
                  IE7A2 $
                  ISTE7 $
                  IE81 $
                  IE82 $
                  IE9A $
                  IE9B $
                  IE9C $
                  IE9D $
                  IE91 $
                  ISTE9 $
                  ITE10 $
                  ITE11 $
                  IX12C $
                  IX12D $
                  IX12E $
                  IX12F $
                  ITX12 $
                  INCE13 $
                  IADA $
                  IA14A $
                  IA14B $
                  IPPE15 $
                  IMEMBR07 $
      ;
label
SURVYEAR		='FISCAL YEAR OF SURVEY (2008)'
FIPS			='FEDERAL INFORMATION PROCESSING STANDARDS (FIPS)'
STABR			='POSTAL STATE ABBREVIATION CODES'
STNAME			='NAME OF THE STATE OR TERRITORY'
R1A				='LOCAL REVENUES PROPERTY TAX'
R1B				='LOCAL REVENUES NONPROPERTY TAX'
R1C				='LOCAL REVENUES LOCAL GOVERNMENT PROPERTY TAX'
R1D				='LOCAL REVENUES LOCAL GOVERNMENT NONPROPERTY TAX'
R1E				='LOCAL REVENUES INDIVIDUAL TUITION'
R1F				='LOCAL REVENUES TUITION FROM LEAS'
R1G				='LOCAL REVENUES TRANSPORTATION FEES FROM INDIVIDUAL'
R1H				='LOCAL REVENUES TRANSPORTATION FEES FROM LEAS'
R1I				='LOCAL REVENUES EARNINGS ON INVESTMENTS'
R1J				='LOCAL REVENUES FOOD SERVICE'
R1K				='LOCAL REVENUES STUDENT ACTIVITIES'
R1L				='LOCAL REVENUES OTHER REVENUES'
R1M				='LOCAL REVENUES TEXTBOOK REVENUES'
R1N				='LOCAL REVENUES SUMMER SCHOOL '
STR1			='LOCAL REVENUES SUBTOTAL'
R2				='INTERMEDIATE REVENUES'
R3				='STATE REVENUES'
R4A				='FEDERAL REVENUES DIRECT GRANTS'
R4B				='FEDERAL REVENUES THRU STATE '
R4C				='FEDERAL REVENUES THRU INTERMEDIATE AGENCIES'
R4D				='FEDERAL REVENUES OTHER SOURCES'
STR4			='FEDERAL REVENUES SUBTOTAL'
R5				='REVENUES FROM OTHER SOURCES'
TR				='TOTAL REVENUES FROM ALL SOURCES'
E11				='INSTRUCTIONAL EXPENDITURES SALARIES'
E12				='INSTRUCTIONAL EXPENDITURES EMPLOYEE BENEFITS'
E13				='INSTRUCTIONAL EXPENDITURES PURCHASED SERVICES'
E14				='INSTRUCTIONAL EXPENDITURES TUITION TO PRIVATE AND OUT-OF-STATE SCHOOLS'
E15				='INSTRUCTIONAL EXPENDITURES TUITION TO OTHER LEAS IN-STATE'
E16				='INSTRUCTIONAL EXPENDITURES SUPPLIES'
E17				='INSTRUCTIONAL EXPENDITURES PROPERTY'
E18				='INSTRUCTIONAL EXPENDITURES OTHER'
STE1			='INSTRUCTIONAL EXPENDITURES SUBTOTAL'
E11A			='TEACHER SALARIES REGULAR PROGRAMS'
E11B			='TEACHER SALARIES SPECIAL EDUCATION PROGRAMS'
E11C			='TEACHER SALARIES VOCATIONAL EDUCATION PROGRAMS'
E11D			='TEACHER SALARIES OTHER EDUCATION PROGRAMS'
E2				='INSTRUCTIONAL EXPENDITURES TEXTBOOKS'
E212			='SUPPORT EXPENDITURES SALARIES STUDENT SUPPORT SERVICES'
E213			='SUPPORT EXPENDITURES SALARIES INSTRUCTIONAL STAFF SUPPORT'
E214			='SUPPORT EXPENDITURES SALARIES GENERAL ADMINISTRATION'
E215			='SUPPORT EXPENDITURES SALARIES SCHOOL ADMINISTRATION'
E216			='SUPPORT EXPENDITURES SALARIES OPERATION & MAINTENANCE'
E217			='SUPPORT EXPENDITURES SALARIES PUPIL TRANSPORTATION'
E218			='SUPPORT EXPENDITURES SALARIES OTHER SERVICES'
TE21			='SUPPORT EXPENDITURES SALARIES SUBTOTAL'
E222			='SUPPORT EXPENDITURES EMPLOYEE BENEFITS STUDENT SUPPORT SERVICES'
E223			='SUPPORT EXPENDITURES EMPLOYEE BENEFITS INSTRUCTIONAL STAFF SUPPORT'
E224			='SUPPORT EXPENDITURES EMPLOYEE BENEFITS GENERAL ADMINISTRATION'
E225			='SUPPORT EXPENDITURES EMPLOYEE BENEFITS SCHOOL ADMINISTRATION'
E226			='SUPPORT EXPENDITURES EMPLOYEE BENEFITS OPERATION & MAINTENANCE'
E227			='SUPPORT EXPENDITURES EMPLOYEE BENEFITS PUPIL TRANSPORTATION'
E228			='SUPPORT EXPENDITURES EMPLOYEE BENEFITS OTHER SERVICES'
TE22			='SUPPORT EXPENDITURES EMPLOYEE BENEFITS SUBTOTAL'
E232			='SUPPORT EXPENDITURES PURCHASED SERVICES STUDENT SUPPORT SERVICES'
E233			='SUPPORT EXPENDITURES PURCHASED SERVICES INSTRUCTIONAL STAFF SUPPORT'
E234			='SUPPORT EXPENDITURES PURCHASED SERVICES GENERAL ADMINISTRATION'
E235			='SUPPORT EXPENDITURES PURCHASED SERVICES SCHOOL ADMINISTRATION'
E236			='SUPPORT EXPENDITURES PURCHASED SERVICES OPERATION & MAINTENANCE'
E237			='SUPPORT EXPENDITURES PURCHASED SERVICES PUPIL TRANSPORTATION'
E238			='SUPPORT EXPENDITURES PURCHASED SERVICES OTHER SERVICES'
TE23			='SUPPORT EXPENDITURES PURCHASED SERVICES SUBTOTAL '
E242			='SUPPORT EXPENDITURES SUPPLIES STUDENT SUPPORT SERVICES'
E243			='SUPPORT EXPENDITURES SUPPLIES INSTRUCTIONAL STAFF SUPPORT'
E244			='SUPPORT EXPENDITURES SUPPLIES GENERAL ADMINISTRATION'
E245			='SUPPORT EXPENDITURES SUPPLIES SCHOOL ADMINISTRATION'
E246			='SUPPORT EXPENDITURES SUPPLIES OPERATION & MAINTENANCE'
E247			='SUPPORT EXPENDITURES SUPPLIES PUPIL TRANSPORTATION'
E248			='SUPPORT EXPENDITURES SUPPLIES OTHER SERVICES'
TE24			='SUPPORT EXPENDITURES SUPPLIES SUBTOTAL'
E252			='SUPPORT EXPENDITURES PROPERTY STUDENT SUPPORT SERVICES'
E253			='SUPPORT EXPENDITURES PROPERTY INSTRUCTIONAL STAFF SUPPORT'
E254			='SUPPORT EXPENDITURES PROPERTY GENERAL ADMINISTRATION'
E255			='SUPPORT EXPENDITURES PROPERTY SCHOOL ADMINISTRATION'
E256			='SUPPORT EXPENDITURES PROPERTY OPERATION & MAINTENANCE'
E257			='SUPPORT EXPENDITURES PROPERTY PUPIL TRANSPORTATION'
E258			='SUPPORT EXPENDITURES PROPERTY OTHER SERVICES'
TE25			='SUPPORT EXPENDITURES PROPERTY SUBTOTAL'
E262			='SUPPORT EXPENDITURES OTHER STUDENT SUPPORT SERVICES'
E263			='SUPPORT EXPENDITURES OTHER INSTRUCTIONAL STAFF SUPPORT'
E264			='SUPPORT EXPENDITURES OTHER GENERAL ADMINISTRATION'
E265			='SUPPORT EXPENDITURES OTHER SCHOOL ADMINISTRATION'
E266			='SUPPORT EXPENDITURES OTHER OPERATION & MAINTENANCE'
E267			='SUPPORT EXPENDITURES OTHER PUPIL TRANSPORTATION'
E268			='SUPPORT EXPENDITURES OTHER SERVICES'
TE26			='SUPPORT EXPENDITURES OTHER SUBTOTAL'
STE22			='SUPPORT EXPENDITURES SUBTOTAL STUDENT SUPPORT SERVICES'
STE23			='SUPPORT EXPENDITURES SUBTOTAL INSTRUCTIONAL STAFF SUPPORT'
STE24			='SUPPORT EXPENDITURES SUBTOTAL GENERAL ADMINISTRATION'
STE25			='SUPPORT EXPENDITURES SUBTOTAL SCHOOL ADMINISTRATION'
STE26			='SUPPORT EXPENDITURES SUBTOTAL OPERATION & MAINTENANCE'
STE27			='SUPPORT EXPENDITURES SUBTOTAL PUPIL TRANSPORTATION'
STE28			='SUPPORT EXPENDITURES SUBTOTAL OTHER SERVICES'
STE2T			='SUPPORT EXPENDITURES TOTAL SUPPORT SERVICES'
E3A11			='NONINSTRUCTIONAL SERVICES FOOD SERVICES SALARIES'
E3A12			='NONINSTRUCTIONAL SERVICES FOOD SERVICES EMPLOYEE BENEFITS'
E3A13			='NONINSTRUCTIONAL SERVICES FOOD SERVICES PURCHASED SERVICES'
E3A14			='NONINSTRUCTIONAL SERVICES FOOD SERVICES SUPPLIES'
E3A2			='NONINSTRUCTIONAL SERVICES FOOD SERVICES PROPERTY'
E3A16			='NONINSTRUCTIONAL SERVICES FOOD SERVICES OTHER '
E3A1			='NONINSTRUCTIONAL SERVICES FOOD SERVICES SUBTOTAL'
E3B11			='NONINSTRUCTIONAL SERVICES ENTERPRISE SALARIES'
E3B12			='NONINSTRUCTIONAL SERVICES ENTERPRISE EMPLOYEE BENEFITS'
E3B13			='NONINSTRUCTIONAL SERVICES ENTERPRISE PURCHASED SERVICES'
E3B14			='NONINSTRUCTIONAL SERVICES ENTERPRISE SUPPLIES'
E3B2			='NONINSTRUCTIONAL SERVICES ENTERPRISE PROPERTY '
E3B16			='NONINSTRUCTIONAL SERVICES ENTERPRISE OTHER'
E3B1			='NONINSTRUCTIONAL SERVICES ENTERPRISE SUBTOTAL '
STE3			='NONINSTRUCTIONAL SERVICES TOTAL'
E4A1			='DIRECT PROGRAM SUPPORT TEXTBOOKS'
E4A2			='DIRECT PROGRAM SUPPORT TEXTBOOKS (PROPERTY)'
E4B1			='DIRECT PROGRAM SUPPORT TRANSPORT'
E4B2			='DIRECT PROGRAM SUPPORT TRANSPORT (PROPERTY)'
E4C1			='DIRECT PROGRAM SUPPORT EMPLOYEE BENEFITS'
E4C2			='DIRECT PROGRAM SUPPORT EMPLOYEE BENEFITS (PROPERTY)'
E4D				='DIRECT PROGRAM SUPPORT PRIVATE SCHOOL STUDENT'
E4E1			='DIRECT PROGRAM SUPPORT OTHER'
E4E2			='DIRECT PROGRAM SUPPORT OTHER (PROPERTY) '
STE4			='DIRECT PROGRAM SUPPORT SUBTOTAL'
TE5				='CURRENT EXPENDITURES'
E61				='FACILITIES ACQUISITION NONPROPERTY'
E62				='FACILITIES ACQUISITION PROPERTY (LAND & BUILDINGS)'
E63				='FACILITIES ACQUISITION PROPERTY (EQUIPMENT)'
STE6			='FACILITIES ACQUISITION NONPROPERTY & PROPERTY TOTAL'
E7A1			='OTHER USE DEBT SERVICE INTEREST'
E7A2			='OTHER USE DEBT SERVICE REDEMPTION'
STE7			='OTHER USE DEBT SERVICE SUBTOTAL'
E81				='COMMUNITY SERVICE NONPROPERTY'
E82				='COMMUNITY SERVICE PROPERTY'
E9A				='DIRECT COST PROGRAM NONPUBLIC SCHOOL'
E9B				='DIRECT COST PROGRAM ADULT EDUCATION'
E9C				='DIRECT COST PROGRAM COMMUNITY COLLEGE'
E9D				='DIRECT COST PROGRAM OTHER'
E91				='DIRECT COST PROGRAM PROPERTY'
STE9			='DIRECT COST PROGRAM SUBTOTAL '
TE10			='PROPERTY TOTAL'
TE11			='TOTAL EXPENDITURES FOR EDUCATION'
X12C			='EXCLUSION FOR PL 100 297 TITLE I '
X12D			='EXCLUSION FOR PL 100 297 TITLE I CARRYOVER'
X12E			='EXCLUSION FOR PL 100 297 TITLE V, PART A'
X12F			='EXCLUSION FOR PL 100 297 TITLE V, PART A CARRYOVER'
TX12			='TOTAL EXCLUSION FOR PL 100 297'
NCE13			='NET CURRENT EXPENDITURES'
ADA				='ADA (STATE AND NCES DEFINITION)'
A14A			='ADA (STATE DEFINITION)'
A14B			='ADA (NCES DEFINITION)'
PPE15			='PER PUPIL EXPENDITURES'
MEMBR07			='TOTAL STUDENT MEMBERSHIP'

IR1A			='IMP FLAG LOCAL REVENUES PROPERTY TAX'
IR1B			='IMP FLAG LOCAL REVENUES NONPROPERTY TAX'
IR1C			='IMP FLAG LOCAL REVENUES LOCAL GOVERNMENT PROPERTY TAX'
IR1D			='IMP FLAG LOCAL REVENUES LOCAL GOVERNMENT NONPROPERTY TAX'
IR1E			='IMP FLAG LOCAL REVENUES INDIVIDUAL TUITION'
IR1F			='IMP FLAG LOCAL REVENUES TUITION FROM LEAS'
IR1G			='IMP FLAG LOCAL REVENUES TRANSPORT FEES FROM INDIVIDUAL'
IR1H			='IMP FLAG LOCAL REVENUES TRANSPORT FEES FROM LEAS'
IR1I			='IMP FLAG LOCAL REVENUES EARNINGS ON INVESTMENT'
IR1J			='IMP FLAG LOCAL REVENUES FOOD SERVICE'
IR1K			='IMP FLAG LOCAL REVENUES STUDENT ACTIVITIES'
IR1L			='IMP FLAG LOCAL REVENUES OTHER REVS'
IR1M			='IMP FLAG LOCAL REVENUES TEXTBOOK REVS'
IR1N			='IMP FLAG LOCAL REVENUES SUMMER SCHOOL'
ISTR1			='IMP FLAG LOCAL REVENUES SUBTOTAL'
IR2				='IMP FLAG INTERMEDIATE REVENUES'
IR3				='IMP FLAG STATE REVENUES'
IR4A			='IMP FLAG RED REV DIRECT GRANTS'
IR4B			='IMP FLAG FEDERAL REVENUES THRU STATE'
IR4C			='IMP FLAG FEDERAL REVENUES THRU INTERMEDIATE AGENCIES'
IR4D			='IMP FLAG FEDERAL REVENUES OTHER SOURCES'
ISTR4			='IMP FLAG FEDERAL REVENUES SUBTOTAL'
IR5				='IMP FLAG OTHER SOURCES OF REVENUES'
ITR				='IMP FLAG TOTAL REVENUES FROM ALL SOURCES'
IE11			='IMP FLAG INSTRUCTIONAL EXPENDITURE SALARIES'
IE12			='IMP FLAG INSTRUCTIONAL EMPLOYEE BENEFITS'
IE13			='IMP FLAG INSTRUCTIONAL EXPENDITURE PURCHASED SERVICES'
IE14			='IMP FLAG INSTRUCTIONAL EXPENDITURE TUITION TO PRIVATE AND OUT-OF-STATE SCHOOLS'
IE15			='IMP FLAG INSTRUCTIONAL EXPENDITURE TUITION TO OTHER LEAS IN-STATE'
IE16			='IMP FLAG INSTRUCTIONAL EXPENDITURE SUPPLIES'
IE17			='IMP FLAG INSTRUCTIONAL EXPENDITURE PROPERTY'
IE18			='IMP FLAG INSTRUCTIONAL EXPENDITURE OTHER'
ISTE1			='IMP FLAG INSTRUCTIONAL EXPENDITURE SUBTOTAL'
IE11A			='IMP FLAG TEACHER SALARIES REGULAR PROGRAMS'
IE11B			='IMP FLAG TEACHER SALARIES SPECIAL EDUCATION PROGRAMS'
IE11C			='IMP FLAG TEACHER SALARIES VOCATIONAL EDUCATION PROGRAMS'
IE11D			='IMP FLAG TEACHER SALARIES OTHER EDUCATION PROGRAMS'
IE2				='IMP FLAG INSTRUCTIONAL EXPENDITURE TEXTBOOKS'
IE212			='IMP FLAG SUPPORT EXPENDITURE SALARIES STUDENT SUPPORT SERVICES'
IE213			='IMP FLAG SUPPORT EXPENDITURE SALARIES INSTRUCTIONAL STAFF SUPPORT'
IE214			='IMP FLAG SUPPORT EXPENDITURE SALARIES GENERAL ADMINISTRATION'
IE215			='IMP FLAG SUPPORT EXPENDITURE SALARIES SCHOOL ADMINISTRATION'
IE216			='IMP FLAG SUPPORT EXPENDITURE SALARIES OPERATION & MAINTENANCE'
IE217			='IMP FLAG SUPPORT EXPENDITURE SALARIES PUPIL TRANSPORTATION'
IE218			='IMP FLAG SUPPORT EXPENDITURE SALARIES OTHER SERVICES'
ITE21			='IMP FLAG SUPPORT EXPENDITURE SALARIES SUBTOTAL'
IE222			='IMP FLAG SUPPORT EXPENDITURE EMPLOYEE BENEFITS STUDENT SUPPORT SERVICES'
IE223			='IMP FLAG SUPPORT EXPENDITURE EMPLOYEE BENEFITS INSTRUCTIONAL STAFF SUPPORT'
IE224			='IMP FLAG SUPPORT EXPENDITURE EMPLOYEE BENEFITS GENERAL ADMINISTRATION'
IE225			='IMP FLAG SUPPORT EXPENDITURE EMPLOYEE BENEFITS SCHOOL ADMINISTRATION'
IE226			='IMP FLAG SUPPORT EXPENDITURE EMPLOYEE BENEFITS OPERATION & MAINTENANCE'
IE227			='IMP FLAG SUPPORT EXPENDITURE EMPLOYEE BENEFITS PUPIL TRANSPORTATION'
IE228			='IMP FLAG SUPPORT EXPENDITURE EMPLOYEE BENEFITS OTHER SERVICES'
ITE22			='IMP FLAG SUPPORT EXPENDITURE EMPLOYEE BENEFITS SUBTOTAL'
IE232			='IMP FLAG SUPPORT EXPENDITURE PURCHASED SERVICES STUDENT SUPPORT SERVICES'
IE233			='IMP FLAG SUPPORT EXPENDITURE PURCHASED SERVICES INSTRUCTIONAL STAFF SUPPORT'
IE234			='IMP FLAG SUPPORT EXPENDITURE PURCHASED SERVICES GENERAL ADMINISTRATION'
IE235			='IMP FLAG SUPPORT EXPENDITURE PURCHASED SERVICES SCHOOL ADMINISTRATION'
IE236			='IMP FLAG SUPPORT EXPENDITURE PURCHASED SERVICES OPERATION & MAINTENANCE'
IE237			='IMP FLAG SUPPORT EXPENDITURE PURCHASED SERVICES PUPIL TRANSPORTATION'
IE238			='IMP FLAG SUPPORT EXPENDITURE PURCHASED SERVICES OTHER SERVICES'
ITE23			='IMP FLAG SUPPORT EXPENDITURE PURCHASED SERVICES SUBTOTAL'
IE242			='IMP FLAG SUPPORT EXPENDITURE SUPPLIES STUDENT SUPPORT SERVICES'
IE243			='IMP FLAG SUPPORT EXPENDITURE SUPPLIES INSTRUCTIONAL STAFF SUPPORT'
IE244			='IMP FLAG SUPPORT EXPENDITURE SUPPLIES GENERAL ADMINISTRATION '
IE245			='IMP FLAG SUPPORT EXPENDITURE SUPPLIES SCHOOL ADMINISTRATION'
IE246			='IMP FLAG SUPPORT EXPENDITURE SUPPLIES OPERATION & MAINTENANCE'
IE247			='IMP FLAG SUPPORT EXPENDITURE SUPPLIES PUPIL TRANSPORTATION'
IE248			='IMP FLAG SUPPORT EXPENDITURE SUPPLIES OTHER SERVICES'
ITE24			='IMP FLAG SUPPORT EXPENDITURE SUPPLIES SUBTOTAL'
IE252			='IMP FLAG SUPPORT EXPENDITURE PROPERTY STUDENT SUPPORT SERVICES'
IE253			='IMP FLAG SUPPORT EXPENDITURE PROPERTY INSTRUCTIONAL STAFF SUPPORT'
IE254			='IMP FLAG SUPPORT EXPENDITURE PROPERTY GENERAL ADMINISTRATION'
IE255			='IMP FLAG SUPPORT EXPENDITURE PROPERTY SCHOOL ADMINISTRATION'
IE256			='IMP FLAG SUPPORT EXPENDITURE PROPERTY OPERATION & MAINTENANCE'
IE257			='IMP FLAG SUPPORT EXPENDITURE PROPERTY PUPIL TRANSPORTATION'
IE258			='IMP FLAG SUPPORT EXPENDITURE PROPERTY OTHER SERVICES'
ITE25			='IMP FLAG SUPPORT EXPENDITURE PROPERTY SUBTOTAL'
IE262			='IMP FLAG SUPPORT EXPENDITURE OTHER INSTRUCTIONAL STUDENT SUPPORT SERVICES'
IE263			='IMP FLAG SUPPORT EXPENDITURE OTHER INSTRUCTIONAL STAFF SUPPORT'
IE264			='IMP FLAG SUPPORT EXPENDITURE OTHER GENERAL ADMINISTRATION'
IE265			='IMP FLAG SUPPORT EXPENDITURE OTHER SCHOOL ADMINISTRATION'
IE266			='IMP FLAG SUPPORT EXPENDITURE OTHER OPERATION & MAINTENANCE'
IE267			='IMP FLAG SUPPORT EXPENDITURE OTHER PUPIL TRANSPORTATION'
IE268			='IMP FLAG SUPPORT EXPENDITURE OTHER SERVICES'
ITE26			='IMP FLAG SUPPORT EXPENDITURE OTHER SUBTOTAL'
ISTE22			='IMP FLAG SUPPORT EXPENDITURE SUBTOTAL STUDENT SUPPORT SERVICES'
ISTE23			='IMP FLAG SUPPORT EXPENDITURE SUBTOTAL INSTRUCTIONAL STAFF SUPPORT'
ISTE24			='IMP FLAG SUPPORT EXPENDITURE SUBTOTAL GENERAL ADMINISTRATION'
ISTE25			='IMP FLAG SUPPORT EXPENDITURE SUBTOTAL SCHOOL ADMINISTRATION'
ISTE26			='IMP FLAG SUPPORT EXPENDITURE SUBTOTAL OPERATION & MAINTENANCE'
ISTE27			='IMP FLAG SUPPORT EXPENDITURE SUBTOTAL PUPIL TRANSPORTATION'
ISTE28			='IMP FLAG SUPPORT EXPENDITURE SUBTOTAL OTHER SERVICES'
ISTE2T			='IMP FLAG SUPPORT EXPENDITURE TOTAL SUPPORT SERVICES'
IE3A11			='IMP FLAG NONINSTRUCTIONAL SERVICES FOOD SERVICES SALARIES'
IE3A12			='IMP FLAG NONINSTRUCTIONAL SERVICES FOOD SERVICES EMPLOYEE BENEFITS'
IE3A13			='IMP FLAG NONINSTRUCTIONAL SERVICES FOOD SERVICES PURCHASED SERVICES'
IE3A14			='IMP FLAG NONINSTRUCTIONAL SERVICES FOOD SERVICES SUPPLIES'
IE3A2			='IMP FLAG NONINSTRUCTIONAL SERVICES FOOD SERVICES PROPERTY'
IE3A16			='IMP FLAG NONINSTRUCTIONAL SERVICES FOOD SERVICES OTHER '
IE3A1			='IMP FLAG NONINSTRUCTIONAL SERVICES FOOD SERVICES SUBTOTAL'
IE3B11			='IMP FLAG NONINSTRUCTIONAL SERVICES ENTERPRISE SALARIES'
IE3B12			='IMP FLAG NONINSTRUCTIONAL SERVICES ENTERPRISE EMPLOYEE BENEFITS'
IE3B13			='IMP FLAG NONINSTRUCTIONAL SERVICES ENTERPRISE PURCHASED SERVICES'
IE3B14			='IMP FLAG NONINSTRUCTIONAL SERVICES ENTERPRISE SUPPLIES'
IE3B2			='IMP FLAG NONINSTRUCTIONAL SERVICES ENTERPRISE PROPERTY'
IE3B16			='IMP FLAG NONINSTRUCTIONAL SERVICES ENTERPRISE OTHER'
IE3B1			='IMP FLAG NONINSTRUCTIONAL SERVICES ENTERPRISE SUBTOTAL'
ISTE3			='IMP FLAG NONINSTRUCTIONAL SERVICES TOTAL'
IE4A1			='IMP FLAG DIRECT PROGRAM SUPPORT TEXTBOOKS'
IE4A2			='IMP FLAG DIRECT PROGRAM SUPPORT TEXTBOOKS (PROP)'
IE4B1			='IMP FLAG DIRECT PROGRAM SUPPORT TRANSPORTATION'
IE4B2			='IMP FLAG DIRECT PROGRAM SUPPORT TRANSPORTATION (PROP)'
IE4C1			='IMP FLAG DIRECT PROGRAM SUPPORT EMPLOYEE BENEFITS'
IE4C2			='IMP FLAG DIRECT PROGRAM SUPPORT EMPLOYEE BENEFITS (PROP)'
IE4D			='IMP FLAG DIRECT PROGRAM SUPPORT PRIVATE SCHOOL STUDENT'
IE4E1			='IMP FLAG DIRECT PROGRAM SUPPORT OTHER'
IE4E2			='IMP FLAG DIRECT PROGRAM SUPPORT OTHER (PROPERTY)'
ISTE4			='IMP FLAG DIRECT PROGRAM SUPPORT SUBTOTAL'
ITE5			='IMP FLAG CURRENT EXPENDITURES'
IE61			='IMP FLAG FACILITIES ACQUISITIONS NON PROPERTY '
IE62			='IMP FLAG FACILITIES ACQUISITIONS PROPERTY(LAND/BUILDINGS)'
IE63			='IMP FLAG FACILITIES ACQUISITIONS EQUIPMENT'
ISTE6			='IMP FLAG FACILITIES ACQUISITIONS TOTAL'
IE7A1			='IMP FLAG OTHER USE DEBT SERVICE INTEREST'
IE7A2			='IMP FLAG OTHER USE REDEMPTION'
ISTE7			='IMP FLAG OTHER USE DEBT SERVICE SUBTOTAL'
IE81			='IMP FLAG COMMUNITY SERVICE NONPROPERTY'
IE82			='IMP FLAG COMMUNITY SERVICE PROPERTY'
IE9A			='IMP FLAG DIRECT COST PROGRAM NONPUBLIC SCHOOL'
IE9B			='IMP FLAG DIRECT COST PROGRAM ADULT EDUCATION'
IE9C			='IMP FLAG DIRECT COST PROGRAM COMMUNITY COLLEGE'
IE9D			='IMP FLAG DIRECT COST PROGRAM OTHER '
IE91			='IMP FLAG DIRECT COST PROGRAM PROPERTY'
ISTE9			='IMP FLAG DIRECT COST PROGRAM SUBTOTAL'
ITE10			='IMP FLAG PROPERTY TOTAL'
ITE11			='IMP FLAG TOTAL EXPENDITURES FOR EDUCATION'
IX12C			='IMP FLAG EXCLUSIVE FOR PL 100 297 TITLE I'
IX12D			='IMP FLAG EXCLUSIVE FOR PL 100 297 TITLE I CARRYOVER'
IX12E			='IMP FLAG EXCLUSIVE FOR PL 100 297 TITLE V, PART A'
IX12F			='IMP FLAG EXCLUSIVE FOR PL 100 297 TITLE V, PART A CARRYOVER'
ITX12			='IMP FLAG TOTAL EXCLUSION FOR PL 100 297'
INCE13			='IMP FLAG NET CURRENT EXPENDITURES'
IADA			='IMP FLAG ADA (STATE AND NCES DEFINITION)'
IA14A			='IMP FLAG ADA (STATE DEFINITION)'
IA14B			='IMP FLAG ADA (NCES DEFINITION)'
IPPE15			='IMP FLAG PER PUPIL EXPENDITURES'
IMEMBR07		='IMP FLAG TOTAL STUDENT MEMBERSHIP';

      if _ERROR_ then call symputx('_EFIERR_',1);  /* set ERROR detection macro variable */
      run;

