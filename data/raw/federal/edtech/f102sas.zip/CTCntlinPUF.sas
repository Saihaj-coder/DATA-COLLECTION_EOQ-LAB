PROC Format;
   Value FLAGF
          0  = "Not imputed"
          1  = "Imputed"
   ;
   Value LEV
          1  = "Elementary"
          3  = "Combined"
   ;
   Value MIN
          1  = "Less than 6 percent"
          2  = "6 to 20 percent"
          3  = "21 to 49 percent"
          4  = "50 percent or more"
   ;
   Value POV
          -9  = "Missing"
          1  = "25 percent or less"
          2  = "26 to 50 percent"
          3  = "51 to 75 percent"
          4  = "76 percent or more"
   ;
   Value Q10AF
          1  = "Strongly disagree"
          2  = "Somewhat disagree"
          3  = "Somewhat agree"
          4  = "Strongly agree"
   ;
   Value Q10BF
          1  = "Strongly disagree"
          2  = "Somewhat disagree"
          3  = "Somewhat agree"
          4  = "Strongly agree"
   ;
   Value Q10CF
          1  = "Strongly disagree"
          2  = "Somewhat disagree"
          3  = "Somewhat agree"
          4  = "Strongly agree"
   ;
   Value Q11F
          1  = "Yes"
          2  = "No"
   ;
   Value Q12AF
          -8  = "Inapplicable"
          1  = "Never"
          2  = "A few times a year"
          3  = "Once a month"
          4  = "2-3 times a month"
          5  = "At least once a week"
   ;
   Value Q12BF
          -8  = "Inapplicable"
          1  = "Never"
          2  = "A few times a year"
          3  = "Once a month"
          4  = "2-3 times a month"
          5  = "At least once a week"
   ;
   Value Q12CF
          -8  = "Inapplicable"
          1  = "Never"
          2  = "A few times a year"
          3  = "Once a month"
          4  = "2-3 times a month"
          5  = "At least once a week"
   ;
   Value Q12DF
          -8  = "Inapplicable"
          1  = "Never"
          2  = "A few times a year"
          3  = "Once a month"
          4  = "2-3 times a month"
          5  = "At least once a week"
   ;
   Value Q12EF
          -8  = "Inapplicable"
          1  = "Never"
          2  = "A few times a year"
          3  = "Once a month"
          4  = "2-3 times a month"
          5  = "At least once a week"
   ;
   Value Q12FF
          -8  = "Inapplicable"
          1  = "Never"
          2  = "A few times a year"
          3  = "Once a month"
          4  = "2-3 times a month"
          5  = "At least once a week"
   ;
   Value Q12GF
          -8  = "Inapplicable"
          1  = "Never"
          2  = "A few times a year"
          3  = "Once a month"
          4  = "2-3 times a month"
          5  = "At least once a week"
   ;
   Value Q13AAF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q13ABF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
          3  = "Don't know"
   ;
   Value Q13ACF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
          3  = "Don't know"
   ;
   Value Q13BAF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q13BBF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
          3  = "Don't know"
   ;
   Value Q13BCF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
          3  = "Don't know"
   ;
   Value Q13CAF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q13CBF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
          3  = "Don't know"
   ;
   Value Q13CCF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
          3  = "Don't know"
   ;
   Value Q13DAF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q13DBF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
          3  = "Don't know"
   ;
   Value Q13DCF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
          3  = "Don't know"
   ;
   Value Q14AF
          -8  = "Inapplicable"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Great extent"
   ;
   Value Q14BF
          -8  = "Inapplicable"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Great extent"
   ;
   Value Q14BOXF
          -8  = "Inapplicable"
          0  = "Not checked"
          1  = "Checked"
   ;
   Value Q14CF
          -8  = "Inapplicable"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Great extent"
   ;
   Value Q14DF
          -8  = "Inapplicable"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Great extent"
   ;
   Value Q14EF
          -8  = "Inapplicable"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Great extent"
   ;
   Value Q14FF
          -8  = "Inapplicable"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Great extent"
   ;
   Value Q14GF
          -8  = "Inapplicable"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Great extent"
   ;
   Value Q15AF
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Great extent"
   ;
   Value Q15BF
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Great extent"
   ;
   Value Q15CF
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Great extent"
   ;
   Value Q15DF
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Great extent"
   ;
   Value Q15EF
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Great extent"
   ;
   Value Q15FF
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Great extent"
   ;
   Value Q2BAF
          1  = "Yes"
          2  = "No"
   ;
   Value Q2CAF
          1  = "Yes"
          2  = "No"
   ;
   Value Q2CBF
          -8  = "Inapplicable"
          1960  = (|4.|)
   ;
   Value Q2DAF
          1  = "Yes"
          2  = "No"
   ;
   Value Q3AAF
          1  = "Yes"
          2  = "No"
   ;
   Value Q3ABF
          -8  = "Inapplicable"
          1  = "Regular/standard/professional"
          2  = "Probationary"
          3  = "Provisional/temporary/emergency"
   ;
   Value Q3BAF
          1  = "Yes"
          2  = "No"
   ;
   Value Q3BBF
          -8  = "Inapplicable"
          1  = "Regular/standard/professional"
          2  = "Probationary"
          3  = "Provisional/temporary/emergency"
   ;
   Value Q6AAF
          1  = "None"
          2  = "1-8 hours"
          3  = "More than 8 hours"
   ;
   Value Q6ABF
          -8  = "Inapplicable"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Great extent"
   ;
   Value Q6BAF
          1  = "None"
          2  = "1-8 hours"
          3  = "More than 8 hours"
   ;
   Value Q6BBF
          -8  = "Inapplicable"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Great extent"
   ;
   Value Q6CAF
          1  = "None"
          2  = "1-8 hours"
          3  = "More than 8 hours"
   ;
   Value Q6CBF
          -8  = "Inapplicable"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Great extent"
   ;
   Value Q6DAF
          1  = "None"
          2  = "1-8 hours"
          3  = "More than 8 hours"
   ;
   Value Q6DBF
          -8  = "Inapplicable"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Great extent"
   ;
   Value Q6EAF
          1  = "None"
          2  = "1-8 hours"
          3  = "More than 8 hours"
   ;
   Value Q6EBF
          -8  = "Inapplicable"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Great extent"
   ;
   Value Q6FAF
          1  = "None"
          2  = "1-8 hours"
          3  = "More than 8 hours"
   ;
   Value Q6FBF
          -8  = "Inapplicable"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Great extent"
   ;
   Value Q6GAF
          1  = "None"
          2  = "1-8 hours"
          3  = "More than 8 hours"
   ;
   Value Q6GBF
          -8  = "Inapplicable"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Great extent"
   ;
   Value Q7BOXF
          0  = "Not checked"
          1  = "Checked"
   ;
   Value Q7F
          -8  = "Inapplicable"
          0  = (|2.|)
   ;
   Value Q8AF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q8BF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q8CF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q8DF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q8EF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q8FF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q9AF
          -8  = "Inapplicable"
          1  = "Never"
          2  = "A few times a year"
          3  = "Once a month"
          4  = "2-3 times a month"
          5  = "At least once a week"
   ;
   Value Q9BF
          -8  = "Inapplicable"
          1  = "Never"
          2  = "A few times a year"
          3  = "Once a month"
          4  = "2-3 times a month"
          5  = "At least once a week"
   ;
   Value Q9BOXF
          0  = "Not checked"
          1  = "Checked"
   ;
   Value Q9CF
          -8  = "Inapplicable"
          1  = "Never"
          2  = "A few times a year"
          3  = "Once a month"
          4  = "2-3 times a month"
          5  = "At least once a week"
   ;
   Value Q9DF
          -8  = "Inapplicable"
          1  = "Never"
          2  = "A few times a year"
          3  = "Once a month"
          4  = "2-3 times a month"
          5  = "At least once a week"
   ;
   Value Q9EF
          1  = "Never"
          2  = "A few times a year"
          3  = "Once a month"
          4  = "2-3 times a month"
          5  = "At least once a week"
   ;
   Value Q9FF
          1  = "Never"
          2  = "A few times a year"
          3  = "Once a month"
          4  = "2-3 times a month"
          5  = "At least once a week"
   ;
   Value Q9GF
          1  = "Never"
          2  = "A few times a year"
          3  = "Once a month"
          4  = "2-3 times a month"
          5  = "At least once a week"
   ;
   Value Q9HF
          1  = "Never"
          2  = "A few times a year"
          3  = "Once a month"
          4  = "2-3 times a month"
          5  = "At least once a week"
   ;
   Value REG
          1  = "Northeast"
          2  = "Southeast"
          3  = "Central"
          4  = "West"
   ;
   Value SIZ
          1  = "Less than 300"
          2  = "300 to 499"
          3  = "500 or more"
   ;
   Value T_Q2ABF
          -9  = "Missing"
          1  = "Prior to 1970"
          1970  = "1970"
          1971  = "1971"
          1972  = "1972"
          1973  = "1973"
          1974  = "1974"
          1975  = "1975"
          1976  = "1976"
          1977  = "1977"
          1978  = "1978"
          1979  = "1979"
          1980  = "1980"
          1981  = "1981"
          1982  = "1982"
          1983  = "1983"
          1984  = "1984"
          1985  = "1985"
          1986  = "1986"
          1987  = "1987"
          1988  = "1988"
          1989  = "1989"
          1990  = "1990"
          1991  = "1991"
          1992  = "1992"
          1993  = "1993"
          1994  = "1994"
          1995  = "1995"
          1996  = "1996"
          1997  = "1997"
          1998  = "1998"
          1999  = "1999"
          2000  = "2000"
          2001  = "2001"
          2002  = "2002"
          2003  = "2003"
          2004  = "2004"
          2005  = "2005"
          2006  = "2006"
          2007  = "2007"
          2008  = "2008"
          2009  = "2009 or later"
   ;
   Value T_Q2BBF
          -8  = "Inapplicable"
          1  = "Prior to 1980"
          2  = "1980 to 1984"
          3  = "1985 to 1989"
          4  = "1990 to 1994"
          1995  = "1995"
          1996  = "1996"
          1997  = "1997"
          1998  = "1998"
          1999  = "1999"
          2000  = "2000"
          2001  = "2001"
          2002  = "2002"
          2003  = "2003"
          2004  = "2004"
          2005  = "2005"
          2006  = "2006"
          2007  = "2007"
          2008  = "2008"
          2009  = "2009"
          2010  = "2010"
   ;
   Value T_Q2DBF
          -8  = "Inapplicable"
          1  = "Prior to 1990"
          2  = "1991 to 1995"
          3  = "1996 to 2010"
   ;
   Value T_Q4F
          1  = "1"
          2  = "2"
          3  = "3"
          4  = "4"
          5  = "5"
          6  = "6"
          7  = "7"
          8  = "8"
          9  = "9"
          10  = "10"
          11  = "11"
          12  = "12"
          13  = "13"
          14  = "14"
          15  = "15"
          16  = "16"
          17  = "17"
          18  = "18"
          19  = "19"
          20  = "20"
          21  = "21"
          22  = "22"
          23  = "23"
          24  = "24"
          25  = "25"
          26  = "26"
          27  = "27"
          28  = "28"
          29  = "29"
          30  = "30"
          31  = "31"
          32  = "32"
          33  = "33"
          34  = "34"
          35  = "35"
          36  = "Over 35 years"
   ;
   Value T_Q5F
          1  = "Fewer than 12"
          12  = "12"
          13  = "13"
          14  = "14"
          15  = "15"
          16  = "16"
          17  = "17"
          18  = "18"
          19  = "19"
          20  = "20"
          21  = "21"
          22  = "22"
          23  = "23"
          24  = "24"
          25  = "25"
          26  = "26"
          27  = "27"
          28  = "28"
          29  = "29"
          30  = "30"
          31  = "Over 30"
   ;
   Value URB
          1  = "City"
          2  = "Suburb"
          3  = "Town"
          4  = "Rural"
   ;
RUN;
