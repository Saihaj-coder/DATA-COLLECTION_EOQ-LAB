PROC Format;
   Value LEPPCTF
          -9  = "Missing"
          1  = "0 percent"
          2  = "0.1 - 2.9 percent"
          3  = "3.0 percent or more"
   ;
   Value METROF
          1  = "City"
          2  = "Suburban"
          3  = "Rural"
   ;
   Value NOF
          -8  = "Not applicable"
          1  = "Zero associated schools"
          2  = "One or more associated schools"
   ;
   Value POVERTF
          -9  = "Missing"
          1  = "Less than 10 percent"
          2  = "10 to 19 percent"
          3  = "20 percent or more"
   ;
   Value PUPTCHF
          -9  = "Missing"
          1  = "Less than 13.0 percent"
          2  = "13.0 - 15.9 percent"
          3  = "16 percent or more"
   ;
   Value Q10AF
          -8  = "Not applicable"
          1  = "Yes"
          2  = "No"
          3  = "Don�t know"
   ;
   Value Q10BF
          -8  = "Not applicable"
          1  = "Yes"
          2  = "No"
          3  = "Don�t know"
   ;
   Value Q10CF
          -8  = "Not applicable"
          1  = "Yes"
          2  = "No"
          3  = "Don�t know"
   ;
   Value Q10DF
          -8  = "Not applicable"
          1  = "Yes"
          2  = "No"
          3  = "Don�t know"
   ;
   Value Q10EF
          -8  = "Not applicable"
          1  = "Yes"
          2  = "No"
          3  = "Don�t know"
   ;
   Value Q10FF
          -8  = "Not applicable"
          1  = "Yes"
          2  = "No"
          3  = "Don�t know"
   ;
   Value Q10GF
          -8  = "Not applicable"
          1  = "Yes"
          2  = "No"
          3  = "Don�t know"
   ;
   Value Q10HF
          -8  = "Not applicable"
          1  = "Yes"
          2  = "No"
          3  = "Don�t know"
   ;
   Value Q10IF
          -8  = "Not applicable"
          1  = "Yes"
          2  = "No"
          3  = "Don�t know"
   ;
   Value Q10JF
          -8  = "Not applicable"
          1  = "Yes"
          2  = "No"
          3  = "Don�t know"
   ;
   Value Q10KF
          -8  = "Not applicable"
          1  = "Yes"
          2  = "No"
          3  = "Don�t know"
   ;
   Value Q11F
          -8  = "Not applicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q12AF
          -8  = "Not applicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q12BF
          -8  = "Not applicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q12CF
          -8  = "Not applicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q13AF
          -8  = "Not applicable"
          1  = "Yes, for all students"
          2  = "Yes, for some students"
          3  = "No"
   ;
   Value Q13BF
          -8  = "Not applicable"
          1  = "Yes, for all students"
          2  = "Yes, for some students"
          3  = "No"
   ;
   Value Q13CF
          -8  = "Not applicable"
          1  = "Yes, for all students"
          2  = "Yes, for some students"
          3  = "No"
   ;
   Value Q14F
          -8  = "Not applicable"
          1  = "Yes"
          2  = "No"
          3  = "Don�t know"
   ;
   Value Q15F
          -8  = "Not applicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q16AF
          -8  = "Not applicable"
          1  = "Not at all"
          2  = "Minor extent"
          3  = "Moderate extent"
          4  = "Major extent"
   ;
   Value Q16BF
          -8  = "Not applicable"
          1  = "Not at all"
          2  = "Minor extent"
          3  = "Moderate extent"
          4  = "Major extent"
   ;
   Value Q16CF
          -8  = "Not applicable"
          1  = "Not at all"
          2  = "Minor extent"
          3  = "Moderate extent"
          4  = "Major extent"
   ;
   Value Q16DF
          -8  = "Not applicable"
          1  = "Not at all"
          2  = "Minor extent"
          3  = "Moderate extent"
          4  = "Major extent"
   ;
   Value Q16EF
          -8  = "Not applicable"
          1  = "Not at all"
          2  = "Minor extent"
          3  = "Moderate extent"
          4  = "Major extent"
   ;
   Value Q16FF
          -8  = "Not applicable"
          1  = "No Other Specified"
          2  = "Minor extent"
          3  = "Moderate extent"
          4  = "Major extent"
   ;
   Value Q2F
          1  = "Yes"
          2  = "No"
   ;
   Value Q6AF
          -8  = "Not applicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q7AF
          -8  = "Not applicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q7BF
          -8  = "Not applicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q7CF
          -8  = "Not applicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q7DF
          -8  = "Not applicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q7EF
          -8  = "Not applicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q8F
          -8  = "Not applicable"
          1  = "a-Internet courses - synchronous"
          2  = "b-Internet courses - asynchronous"
          3  = "c-two-way interactive video"
          4  = "d-one-way prerecorded video"
          5  = "e-other technologies"
   ;
   Value Q9AF
          -8  = "Not applicable"
          1  = "Not important"
          2  = "Somewhat important"
          3  = "Very important"
          4  = "Don�t know"
   ;
   Value Q9BF
          -8  = "Not applicable"
          1  = "Not important"
          2  = "Somewhat important"
          3  = "Very important"
          4  = "Don�t know"
   ;
   Value Q9CF
          -8  = "Not applicable"
          1  = "Not important"
          2  = "Somewhat important"
          3  = "Very important"
          4  = "Don�t know"
   ;
   Value Q9DF
          -8  = "Not applicable"
          1  = "Not important"
          2  = "Somewhat important"
          3  = "Very important"
          4  = "Don�t know"
   ;
   Value Q9EF
          -8  = "Not applicable"
          1  = "Not important"
          2  = "Somewhat important"
          3  = "Very important"
          4  = "Don�t know"
   ;
   Value Q9FF
          -8  = "Not applicable"
          1  = "Not important"
          2  = "Somewhat important"
          3  = "Very important"
          4  = "Don�t know"
   ;
   Value Q9GF
          -8  = "Not applicable"
          1  = "Not important"
          2  = "Somewhat important"
          3  = "Very important"
          4  = "Don�t know"
   ;
   Value Q9HF
          -8  = "Not applicable"
          1  = "No Other Specified"
          2  = "Somewhat important"
          3  = "Very important"
   ;
   Value SF
          -8  = "Not applicable"
   ;
   Value IMPF
          0 = "Not Imputed"
          1 = "Imputed"
   ;          
RUN;
