PROC Format;
   Value $FLAGF
         "0 " = "Not imputed"
         "1 " = "Imputed"
   ;
   Value DSIZCL3F
          1  = "Less than 2000"
          2  = "2000 - 4999"
          3  = "5000 or more"
   ;
   Value OEREGF
          1  = "Northeast"
          2  = "Southeast"
          3  = "Central"
          4  = "West"
   ;
   Value Q10AF
          -8  = "Inapplicable"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Large extent"
          5  = "Very large extent"
   ;
   Value Q10BF
          -8  = "Inapplicable"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Large extent"
          5  = "Very large extent"
   ;
   Value Q10CF
          -8  = "Inapplicable"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Large extent"
          5  = "Very large extent"
   ;
   Value Q10DF
          -8  = "Inapplicable"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Large extent"
          5  = "Very large extent"
   ;
   Value Q10EF
          -8  = "Inapplicable"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Large extent"
          5  = "Very large extent"
   ;
   Value Q10FF
          -8  = "Inapplicable"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Large extent"
          5  = "Very large extent"
   ;
   Value Q10GF
          -8  = "Inapplicable"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Large extent"
          5  = "Very large extent"
   ;
   Value Q10HF
          -8  = "Inapplicable"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Large extent"
          5  = "Very large extent"
   ;
   Value Q10IF
          -8  = "Inapplicable"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Large extent"
          5  = "Very large extent"
   ;
   Value Q10JF
          -8  = "Inapplicable"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Large extent"
          5  = "Very large extent"
   ;
   Value Q10KF
          -8  = "Inapplicable"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Large extent"
          5  = "Very large extent"
   ;
   Value Q10LF
          -8  = "Inapplicable"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Large extent"
          5  = "Very large extent"
   ;
   Value Q10MF
          -8  = "Inapplicable"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Large extent"
          5  = "Very large extent"
   ;
   Value Q10NF
          -8  = "Inapplicable"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Large extent"
          5  = "Very large extent"
   ;
   Value Q11AF
          -8  = "Inapplicable"
          1  = "Not a barrier"
          2  = "Small barrier"
          3  = "Moderate barrier"
          4  = "Large barrier"
          5  = "Very large barrier"
   ;
   Value Q11BF
          -8  = "Inapplicable"
          1  = "Not a barrier"
          2  = "Small barrier"
          3  = "Moderate barrier"
          4  = "Large barrier"
          5  = "Very large barrier"
   ;
   Value Q11CF
          -8  = "Inapplicable"
          1  = "Not a barrier"
          2  = "Small barrier"
          3  = "Moderate barrier"
          4  = "Large barrier"
          5  = "Very large barrier"
   ;
   Value Q11DF
          -8  = "Inapplicable"
          1  = "Not a barrier"
          2  = "Small barrier"
          3  = "Moderate barrier"
          4  = "Large barrier"
          5  = "Very large barrier"
   ;
   Value Q11EF
          -8  = "Inapplicable"
          1  = "Not a barrier"
          2  = "Small barrier"
          3  = "Moderate barrier"
          4  = "Large barrier"
          5  = "Very large barrier"
   ;
   Value Q11FF
          -8  = "Inapplicable"
          1  = "Not a barrier"
          2  = "Small barrier"
          3  = "Moderate barrier"
          4  = "Large barrier"
          5  = "Very large barrier"
   ;
   Value Q11GF
          -8  = "Inapplicable"
          1  = "Not a barrier"
          2  = "Small barrier"
          3  = "Moderate barrier"
          4  = "Large barrier"
          5  = "Very large barrier"
   ;
   Value Q11HF
          -8  = "Inapplicable"
          1  = "Not a barrier"
          2  = "Small barrier"
          3  = "Moderate barrier"
          4  = "Large barrier"
          5  = "Very large barrier"
   ;
   Value Q12AF
          -8  = "Inapplicable"
          1  = "Not a barrier"
          2  = "Small barrier"
          3  = "Moderate barrier"
          4  = "Large barrier"
          5  = "Very large barrier"
   ;
   Value Q12BF
          -8  = "Inapplicable"
          1  = "Not a barrier"
          2  = "Small barrier"
          3  = "Moderate barrier"
          4  = "Large barrier"
          5  = "Very large barrier"
   ;
   Value Q12CF
          -8  = "Inapplicable"
          1  = "Not a barrier"
          2  = "Small barrier"
          3  = "Moderate barrier"
          4  = "Large barrier"
          5  = "Very large barrier"
   ;
   Value Q12DF
          -8  = "Inapplicable"
          1  = "Not a barrier"
          2  = "Small barrier"
          3  = "Moderate barrier"
          4  = "Large barrier"
          5  = "Very large barrier"
   ;
   Value Q12EF
          -8  = "Inapplicable"
          1  = "Not a barrier"
          2  = "Small barrier"
          3  = "Moderate barrier"
          4  = "Large barrier"
          5  = "Very large barrier"
   ;
   Value Q12FF
          -8  = "Inapplicable"
          1  = "Not a barrier"
          2  = "Small barrier"
          3  = "Moderate barrier"
          4  = "Large barrier"
          5  = "Very large barrier"
   ;
   Value Q12GF
          -8  = "Inapplicable"
          1  = "Not a barrier"
          2  = "Small barrier"
          3  = "Moderate barrier"
          4  = "Large barrier"
          5  = "Very large barrier"
   ;
   Value Q12HF
          -8  = "Inapplicable"
          1  = "Not a barrier"
          2  = "Small barrier"
          3  = "Moderate barrier"
          4  = "Large barrier"
          5  = "Very large barrier"
   ;
   Value Q12IF
          -8  = "Inapplicable"
          1  = "Not a barrier"
          2  = "Small barrier"
          3  = "Moderate barrier"
          4  = "Large barrier"
          5  = "Very large barrier"
   ;
   Value Q13AF
          -8  = "Inapplicable"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Large extent"
          5  = "Very large extent"
   ;
   Value Q13BF
          -8  = "Inapplicable"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Large extent"
          5  = "Very large extent"
   ;
   Value Q13BOXF
          -8  = "Inapplicable"
          1  = "Checked"
          2  = "Not checked"
   ;
   Value Q13CF
          -8  = "Inapplicable"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Large extent"
          5  = "Very large extent"
   ;
   Value Q13DF
          -8  = "Inapplicable"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Large extent"
          5  = "Very large extent"
   ;
   Value Q13EF
          -8  = "Inapplicable"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Large extent"
          5  = "Very large extent"
   ;
   Value Q13FF
          -8  = "Inapplicable"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Large extent"
          5  = "Very large extent"
   ;
   Value Q13GF
          -8  = "Inapplicable"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Large extent"
          5  = "Very large extent"
   ;
   Value Q13HF
          -8  = "Inapplicable"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Large extent"
          5  = "Very large extent"
   ;
   Value Q13IF
          -8  = "Inapplicable"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Large extent"
          5  = "Very large extent"
   ;
   Value Q13JF
          -8  = "Inapplicable"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Large extent"
          5  = "Very large extent"
   ;
   Value Q14AF
          -8  = "Inapplicable"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Large extent"
          5  = "Very large extent"
   ;
   Value Q14BF
          -8  = "Inapplicable"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Large extent"
          5  = "Very large extent"
   ;
   Value Q14CF
          -8  = "Inapplicable"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Large extent"
          5  = "Very large extent"
   ;
   Value Q14DF
          -8  = "Inapplicable"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Large extent"
          5  = "Very large extent"
   ;
   Value Q14EF
          -8  = "Inapplicable"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Large extent"
          5  = "Very large extent"
   ;
   Value Q14FF
          -8  = "Inapplicable"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Large extent"
          5  = "Very large extent"
   ;
   Value Q14GF
          -8  = "Inapplicable"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Large extent"
          5  = "Very large extent"
   ;
   Value Q14HF
          -8  = "Inapplicable"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Large extent"
          5  = "Very large extent"
   ;
   Value Q14IF
          -8  = "Inapplicable"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Large extent"
          5  = "Very large extent"
   ;
   Value Q14JF
          -8  = "Inapplicable"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Large extent"
          5  = "Very large extent"
   ;
   Value Q15F
          1  = "Yes"
          2  = "No"
          3  = "Not applicable, this district is a CTE district"
   ;
   Value Q1F
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q2AF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q2BF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q2CF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q2DF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q2EF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q3AF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q3BF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q3CF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q3DF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q3EF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q3FF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q4F
          -8  = "Inapplicable"
          1  = "None"
          2  = "Few"
          3  = "Some"
          4  = "Most"
          5  = "All"
   ;
   Value Q5F
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q6F
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q7F
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q8AF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q8BF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q8CF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q8DF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q8EF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q9F
          -8  = "Inapplicable"
          1  = "None"
          2  = "Few"
          3  = "Some"
          4  = "Most"
          5  = "All"
   ;
   Value URBANF
          1  = "City"
          2  = "Suburban"
          3  = "Town"
          4  = "Rural"
   ;
RUN;
