PROC Format;
   Value DISTYPEF
          1  = "Regular district"
          2  = "Charter school agency"
   ;
   Value FLAGF
          0  = "Not imputed"
          1  = "Imputed"
   ;
   Value POVSTF
          1  = "Less than 10 percent"
          2  = "10-19 percent"
          3  = "20 percent and more"
   ;
   Value Q10A1F
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
          3  = "Don�t know"
   ;
   Value Q10B1F
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
          3  = "Don�t know"
   ;
   Value Q10C1F
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
          3  = "Don�t know"
   ;
   Value Q10D1F
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
          3  = "Don�t know"
   ;
   Value Q10E1F
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
          3  = "Don�t know"
   ;
   Value Q10F1F
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
          3  = "Don�t know"
   ;
   Value Q10G1F
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
          3  = "Don�t know"
   ;
   Value Q10H1F
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
          3  = "Don�t know"
   ;
   Value Q10I1F
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
          3  = "Don�t know"
   ;
   Value Q10J1F
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
          3  = "Don�t know"
   ;
   Value Q10K1F
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
          3  = "Don�t know"
   ;
   Value Q10L1F
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
          3  = "Don�t know"
   ;
   Value Q10P2F
          -8  = "Inapplicable"
          -7  = "Not ranked in top 5"
          1  = "Ranked 1 (Most)"
          2  = "Ranked 2"
          3  = "Ranked 3"
          4  = "Ranked 4"
          5  = "Ranked 5 (Least)"
   ;
   Value Q11F
          -8  = "Inapplicable"
          1  = "1: All courses developed by your district"
          2  = "2"
          3  = "3: Courses developed about equally"
          4  = "4"
          5  = "5: All courses developed by other entities"
   ;
   Value Q12AF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q12BF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q12CF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q12DF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q12EF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q13AF
          -8  = "Inapplicable"
          1  = "Not important"
          2  = "Somewhat important"
          3  = "Very important"
          4  = "Don�t know"
   ;
   Value Q13BF
          -8  = "Inapplicable"
          1  = "Not important"
          2  = "Somewhat important"
          3  = "Very important"
          4  = "Don�t know"
   ;
   Value Q13CF
          -8  = "Inapplicable"
          1  = "Not important"
          2  = "Somewhat important"
          3  = "Very important"
          4  = "Don�t know"
   ;
   Value Q13DF
          -8  = "Inapplicable"
          1  = "Not important"
          2  = "Somewhat important"
          3  = "Very important"
          4  = "Don�t know"
   ;
   Value Q13EF
          -8  = "Inapplicable"
          1  = "Not important"
          2  = "Somewhat important"
          3  = "Very important"
          4  = "Don�t know"
   ;
   Value Q13FF
          -8  = "Inapplicable"
          1  = "Not important"
          2  = "Somewhat important"
          3  = "Very important"
          4  = "Don�t know"
   ;
   Value Q13GF
          -8  = "Inapplicable"
          1  = "Not important"
          2  = "Somewhat important"
          3  = "Very important"
          4  = "Don�t know"
   ;
   Value Q13HF
          -8  = "Inapplicable"
          1  = "Not important"
          2  = "Somewhat important"
          3  = "Very important"
          4  = "Don�t know"
   ;
   Value Q13IF
          -8  = "Inapplicable"
          1  = "Not important"
          2  = "Somewhat important"
          3  = "Very important"
          4  = "Don�t know"
   ;
   Value Q14AF
          -8  = "Inapplicable"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Large extent"
   ;
   Value Q14BF
          -8  = "Inapplicable"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Large extent"
   ;
   Value Q14CF
          -8  = "Inapplicable"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Large extent"
   ;
   Value Q14DF
          -8  = "Inapplicable"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Large extent"
   ;
   Value Q14EF
          -8  = "Inapplicable"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Large extent"
   ;
   Value Q14FF
          -8  = "Inapplicable"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Large extent"
   ;
   Value Q15F
          -8  = "Inapplicable"
          1  = "a: Internet synchronous instruction"
          2  = "b: Internet asynchronous instruction"
          3  = "c: Computer-based other than Internet"
          4  = "d: Two-way interactive video"
          5  = "e: One-way prerecorded video"
          6  = "f: Other (specified)"
   ;
   Value Q16F
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q17AF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q17BF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q17CF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q18F
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q19F
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
          3  = "Don�t know"
   ;
   Value Q1F
          1  = "Yes"
          2  = "No"
   ;
   Value Q2AF
          -8  = "Inapplicable"
          1  = (|5.|)
   ;
   Value Q2BF
          -8  = "Inapplicable"
          0  = (|4.|)
   ;
   Value Q2CF
          -8  = "Inapplicable"
          0  = (|5.|)
   ;
   Value Q2DF
          -8  = "Inapplicable"
          0  = (|5.|)
   ;
   Value Q2EF
          -8  = "Inapplicable"
          0  = (|5.|)
   ;
   Value Q3F
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
          3  = "Don�t know"
   ;
   Value Q4F
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q5AF
          -8  = "Inapplicable"
          1  = "Yes, for all courses"
          2  = "Yes, for some courses"
          3  = "No"
   ;
   Value Q5BF
          -8  = "Inapplicable"
          1  = "Yes, for all courses"
          2  = "Yes, for some courses"
          3  = "No"
   ;
   Value Q5CF
          -8  = "Inapplicable"
          1  = "Yes, for all courses"
          2  = "Yes, for some courses"
          3  = "No"
   ;
   Value Q6AF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q6BF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q6CF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q6DF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q6EF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q6FF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q7AF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q7BF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q8BOXF
          -8  = "Inapplicable"
          0  = "Not Checked"
          1  = "Checked"
   ;
   Value Q8F
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q9F
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value REGIONF
          1  = "Northeast"
          2  = "Southeast"
          3  = "Central"
          4  = "West"
   ;
   Value SIZEF
          1  = "Less than 2500"
          2  = "2500-9999"
          3  = "10000 or more"
   ;
   Value URBANF
          1  = "City"
          2  = "Suburban"
          3  = "Town"
          4  = "Rural"
   ;
RUN;
