PROC Format;
   Value FLAGF
          0  = "NOT IMPUTED"
          1  = "IMPUTED"
   ;
   Value FRELNCHF
          1  = "LESS THAN 35 PERCENT"
          2  = "35 TO 49 PERCENT"
          3  = "50 TO 74 PERCENT"
          4  = "75 PERCENT OR MORE"
   ;
   Value LOCALEF
          1  = "CITY"
          2  = "URBAN FRINGE"
          3  = "TOWN"
          4  = "RURAL"
   ;
   Value NSIZ_CF
          1  = "LESS THAN 300"
          2  = "300 TO 999"
          3  = "1000 OR MORE"
   ;
   Value OEREGF
          1  = "NORTHEAST"
          2  = "SOUTHEAST"
          3  = "CENTRAL"
          4  = "WEST"
   ;
   Value PUPTCHF
          -9  = "MISSING"
          1  = "LESS THAN 14.0 PERCENT"
          2  = "14.0 TO 16.9 PERCENT"
          3  = "17.0 PERCENT OR MORE"
   ;
   Value Q10F
          -8  = "NOT APPLICABLE"
          1  = "YES"
          2  = "NO"
   ;
   Value Q11AF
          -8  = "NOT APPLICABLE"
          1  = "YES"
          2  = "NO"
   ;
   Value Q11BF
          -8  = "NOT APPLICABLE"
          1  = "YES"
          2  = "NO"
   ;
   Value Q12F
          -8  = "NOT APPLICABLE"
          0 - 150  = (|3.|)
   ;
   Value Q13F
          -8  = "NOT APPLICABLE"
          1  = "YES"
          2  = "NO"
   ;
   Value Q14AF
          -8  = "NOT APPLICABLE"
          1  = "YES"
          2  = "NO"
   ;
   Value Q14BF
          -8  = "NOT APPLICABLE"
          1  = "YES"
          2  = "NO"
   ;
   Value Q14CF
          -8  = "NOT APPLICABLE"
          1  = "YES"
          2  = "NO"
   ;
   Value Q14DF
          -8  = "NOT APPLICABLE"
          1  = "YES"
          2  = "NO"
   ;
   Value Q14EF
          -8  = "NOT APPLICABLE"
          1  = "YES"
          2  = "NO"
   ;
   Value Q14FF
          -8  = "NOT APPLICABLE"
          1  = "YES"
          2  = "NO"
   ;
   Value Q14GF
          -8  = "NOT APPLICABLE"
          1  = "YES"
          2  = "NO"
   ;
   Value Q14HF
          -8  = "NOT APPLICABLE"
          1  = "YES"
          2  = "NO"
   ;
   Value Q15F
          -8  = "NOT APPLICABLE"
          1  = "YES"
          2  = "NO"
   ;
   Value Q16AF
          -8  = "NOT APPLICABLE"
          1  = "YES"
          2  = "NO"
   ;
   Value Q16BF
          -8  = "NOT APPLICABLE"
          1  = "YES"
          2  = "NO"
   ;
   Value Q16CF
          -8  = "NOT APPLICABLE"
          1  = "YES"
          2  = "NO"
   ;
   Value Q16DF
          -8  = "NOT APPLICABLE"
          1  = "YES"
          2  = "NO"
   ;
   Value Q16EF
          -8  = "NOT APPLICABLE"
          1  = "YES"
          2  = "NO"
   ;
   Value Q16FF
          -8  = "NOT APPLICABLE"
          1  = "YES"
          2  = "NO"
   ;
   Value Q16GF
          -8  = "NOT APPLICABLE"
          1  = "YES"
          2  = "NO"
   ;
   Value Q17F
          -8  = "NOT APPLICABLE"
          1  = "YES"
          2  = "NO"
   ;
   Value Q18AF
          -8  = "NOT APPLICABLE"
          1  = "YES"
          2  = "NO"
   ;
   Value Q18BF
          -8  = "NOT APPLICABLE"
          1  = "YES"
          2  = "NO"
   ;
   Value Q18CF
          -8  = "NOT APPLICABLE"
          1  = "YES"
          2  = "NO"
   ;
   Value Q19F
          -8  = "NOT APPLICABLE"
          2 - 1650  = (|4.|)
   ;
   Value Q1F
          1 - 225  = (|3.|)
   ;
   Value Q20F
          -8  = "NOT APPLICABLE"
          1  = "YES"
          2  = "NO"
   ;
   Value Q21F
          -8  = "NOT APPLICABLE"
          1  = "DAILY"
          2  = "WEEKLY"
          3  = "MONTHLY"
          4  = "LESS THAN MONTHLY"
   ;
   Value Q22F
          -8  = "NOT APPLICABLE"
          1  = "FULL-TIME PAID SCHOOL TECH DIR/COORD"
          2  = "PART-TIME PAID SCHOOL TECH DIR/COORD"
          3  = "DISTRICT STAFF"
          4  = "CONSULTANT/OUTSIDE CONTRACTOR"
          5  = "TEACH/OTHER STAFF AS PART OF FORMAL RESP"
          6  = "TEACHER OR OTHER STAFF AS VOLUNTEERS"
          7  = "STUDENTS"
          8  = "OTHER"
   ;
   Value Q23F
          -8  = "NOT APPLICABLE"
          1  = "YES"
          2  = "NO"
   ;
   Value Q24F
          -8  = "NOT APPLICABLE"
          1  = "0 PERCENT"
          2  = "1 TO 25 PERCENT"
          3  = "26 TO 50 PERCENT"
          4  = "51 TO 75 PERCENT"
          5  = "76 TO 100 PERCENT"
   ;
   Value Q25F
          1  = "YES"
          2  = "NO"
   ;
   Value Q26F
          -8  = "NOT APPLICABLE"
          1 - 791  = (|3.|)
   ;
   Value Q27F
          -8  = "NOT APPLICABLE"
          1  = "LESS THAN 1 WEEK"
          2  = "1 WEEK TO LESS THAN 1 MONTH"
          3  = "1 MONTH TO LESS THAN 3 MONTHS"
          4  = "3 MONTHS TO LESS THAN 6 MONTHS"
          6  = "THE ENTIRE SCHOOL YEAR"
          7  = "OTHER"
   ;
   Value Q28F
          -8  = "NOT APPLICABLE"
          1  = "YES"
          2  = "NO"
   ;
   Value Q29F
          -8  = "NOT APPLICABLE"
          1  = "YES"
          2  = "NO"
   ;
   Value Q2F
          3 - 2200  = (|4.|)
   ;
   Value Q30F
          1  = "YES"
          2  = "NO"
   ;
   Value Q31F
          -8  = "NOT APPLICABLE"
          1 - 600  = (|3.|)
   ;
   Value Q3F
          0  = "NO INSTRUCTIONAL COMPUTERS"
          3 - 2200  = (|4.|)
   ;
   Value Q4F
          1  = "YES"
          2  = "NO"
   ;
   Value Q5F
          -8  = "NOT APPLICABLE"
          1 - 2200  = (|4.|)
   ;
   Value Q6F
          -8  = "NOT APPLICABLE"
          0 - 2200  = (|4.|)
   ;
   Value Q7F
          -8  = "NOT APPLICABLE"
          1  = "FULL-TIME PAID SCHOOL TECH/DIR COORD"
          2  = "PART-TIME PAID SCHOOL TECH DIR/COORD"
          3  = "DISTRICT STAFF"
          4  = "CONSULTANT/OUTSIDE CONTRACTOR"
          5  = "TEACHER/OTHER STAFF AS PART OF FORMAL RESP"
          6  = "TEACHER OR OTHER STAFF AS VOLUNTEERS"
          7  = "OTHER"
   ;
   Value Q8AF
          -8  = "NOT APPLICABLE"
          1  = "YES"
          2  = "NO"
   ;
   Value Q8BF
          -8  = "NOT APPLICABLE"
          1  = "YES"
          2  = "NO"
   ;
   Value Q9F
          -8  = "NOT APPLICABLE"
          0 - 225  = (|3.|)
   ;
   Value SLEVELF
          1  = "ELEMENTARY"
          2  = "SECONDARY"
          3  = "OTHER"
   ;
RUN;
