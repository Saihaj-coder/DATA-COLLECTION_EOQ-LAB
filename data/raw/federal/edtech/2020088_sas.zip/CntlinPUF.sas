PROC Format;
   Value $FLAGF
         "0 " = "Not imputed"
         "1 " = "Imputed"
   ;
   Value LEVEL3F
          1  = "Primary school"
          2  = "Middle school"
          3  = "High and other school"
   ;
   Value POVST4F
          1  = "Less than 35 percent or missing"
          2  = "35 to 49 percent"
          3  = "50 to 74 percent"
          4  = "75 percent or more"
   ;
   Value Q11F
          -8  = "Inapplicable"
          1  = "1 Very available"
          2  = "2 Somewhat available"
          3  = "3 Slightly available"
          4  = "4 Not available"
          5  = "5 Don�t know"
   ;
   Value Q12F
          -8  = "Inapplicable"
          1  = "1 Very likely"
          2  = "2 Somewhat likely"
          3  = "3 Slightly likely"
          4  = "4 Not likely"
          5  = "5 Don�t know"
   ;
   Value Q14F
          -8  = "Inapplicable"
          1  = "1 Very useful"
          2  = "2 Somewhat useful"
          3  = "3 Slightly useful"
          4  = "4 Not useful"
   ;
   Value Q15F
          -8  = "Inapplicable"
          1  = "1 Very available"
          2  = "2 Somewhat available"
          3  = "3 Slightly available"
          4  = "4 Not available"
          5  = "5 Don�t know"
   ;
   Value Q16F
          -8  = "Inapplicable"
          1  = "1 Very likely"
          2  = "2 Somewhat likely"
          3  = "3 Slightly likely"
          4  = "4 Not likely"
          5  = "5 Don�t know"
   ;
   Value Q17F
          1  = "1 No influence"
          2  = "2 Small influence"
          3  = "3 Moderate influence"
          4  = "4 Large influence"
   ;
   Value Q18F
          1  = "1 Never"
          2  = "2 Rarely"
          3  = "3 Sometimes"
          4  = "4 Often"
   ;
   Value Q19F
          1  = "1 Never"
          2  = "2 Rarely"
          3  = "3 Sometimes"
          4  = "4 Often"
   ;
   Value Q1F
          1  = "Yes"
          2  = "No"
   ;
   Value Q20F
          -8  = "Inapplicable"
          1  = "1 Not at all"
          2  = "2 Small extent"
          3  = "3 Moderate extent"
          4  = "4 Large extent"
   ;
   Value Q21AF
          -8  = "Inapplicable"
          1  = "1 Not at all"
          2  = "2 Small extent"
          3  = "3 Moderate extent"
          4  = "4 Large extent"
   ;
   Value Q21BF
          -8  = "Inapplicable"
          1  = "1 Not at all"
          2  = "2 Small extent"
          3  = "3 Moderate extent"
          4  = "4 Large extent"
   ;
   Value Q21CF
          -8  = "Inapplicable"
          1  = "1 Not at all"
          2  = "2 Small extent"
          3  = "3 Moderate extent"
          4  = "4 Large extent"
   ;
   Value Q21DF
          -8  = "Inapplicable"
          1  = "1 Not at all"
          2  = "2 Small extent"
          3  = "3 Moderate extent"
          4  = "4 Large extent"
   ;
   Value Q21EF
          -8  = "Inapplicable"
          1  = "1 Not at all"
          2  = "2 Small extent"
          3  = "3 Moderate extent"
          4  = "4 Large extent"
   ;
   Value Q22F
          1  = "1 Very prepared"
          2  = "2 Somewhat prepared"
          3  = "3 Slightly prepared"
          4  = "4 Not prepared"
          5  = "5 Not applicable (no online or computerized assessments)"
   ;
   Value Q2F
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q3F
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q4F
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q5F
          1  = "Yes"
          2  = "No"
   ;
   Value Q6F
          1  = "Yes"
          2  = "No"
   ;
   Value Q7AF
          -8  = "Inapplicable"
          1  = "1 Very knowledgeable"
          2  = "2 Somewhat knowledgeable"
          3  = "3 Slightly knowledgeable"
          4  = "4 Not knowledgeable"
   ;
   Value Q7BF
          1  = "1 Very knowledgeable"
          2  = "2 Somewhat knowledgeable"
          3  = "3 Slightly knowledgeable"
          4  = "4 Not knowledgeable"
   ;
   Value Q8AF
          1  = "Yes"
          2  = "No"
   ;
   Value Q8BF
          1  = "Yes"
          2  = "No"
   ;
   Value Q8CF
          1  = "Yes"
          2  = "No"
   ;
   Value Q8DF
          1  = "Yes"
          2  = "No"
   ;
   Value Q9AF
          1  = "1 Not at all"
          2  = "2 Small extent"
          3  = "3 Moderate extent"
          4  = "4 Large extent"
   ;
   Value Q9BF
          1  = "1 Not at all"
          2  = "2 Small extent"
          3  = "3 Moderate extent"
          4  = "4 Large extent"
   ;
   Value Q9CF
          1  = "1 Not at all"
          2  = "2 Small extent"
          3  = "3 Moderate extent"
          4  = "4 Large extent"
   ;
   Value Q9DF
          1  = "1 Not at all"
          2  = "2 Small extent"
          3  = "3 Moderate extent"
          4  = "4 Large extent"
   ;
   Value Q9EF
          1  = "1 Not at all"
          2  = "2 Small extent"
          3  = "3 Moderate extent"
          4  = "4 Large extent"
   ;
   Value Q9FF
          1  = "1 Not at all"
          2  = "2 Small extent"
          3  = "3 Moderate extent"
          4  = "4 Large extent"
   ;
   Value SIZCL4F
          1  = "Less than 300"
          2  = "300-499"
          3  = "500-999"
          4  = "1,000 or more"
   ;
   Value URBANF
          1  = "City"
          2  = "Suburban"
          3  = "Town"
          4  = "Rural"
   ;
RUN;
