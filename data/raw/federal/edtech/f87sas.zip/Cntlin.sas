PROC Format;
   Value ASIZCF
          1  = "LESS THAN 300"
          2  = "300 TO 499"
          3  = "500 OR MORE"
   ;
   Value FRELNF
          -9  = "(MISSING POVERTY STATUS)"
          1  = "LESS THAN 35 PERCENT"
          2  = "35 TO 49 PERCENT"
          3  = "50 TO 74 PERCENT"
          4  = "75 OR MORE PERCENT"
   ;
   Value GFNDR1F
          1  = "Yes"
          2  = "No"
          3  = "Don't know"
   ;
   Value MINSTF
          -9  = "(MISSING PERCENT MINORITY)"
          1  = "LESS THAN 6 PERCENT"
          2  = "6 TO 20 PERCENT"
          3  = "21 TO 49 PERCENT"
          4  = "50 OR MORE PERCENT"
   ;
   Value OEREGF
          1  = "NORTHEAST"
          2  = "SOUTHEAST"
          3  = "CENTRAL"
          4  = "WEST"
   ;
   Value Q10F
          1  = "Yes"
          2  = "No"
          3  = "Don�t know"
          4  = "Not applicable"
   ;
   Value Q11F
          -8  = "Inapplicable"
          1  = "Not Ap/no service"
          2  = "School/district"
          3  = "Private entity"
          4  = "Other entity"
   ;
   Value Q1213SF
          -8  = "Inapplicable"
   ;
   Value Q12ADYF
          -8  = "Inapplicable"
   ;
   Value Q12AMIF
          -8  = "Inapplicable"
   ;
   Value Q12ATMF
          -8  = "Inapplicable"
   ;
   Value Q12BDYF
          -8  = "Inapplicable"
   ;
   Value Q12BMIF
          -8  = "Inapplicable"
   ;
   Value Q12BTMF
          -8  = "Inapplicable"
   ;
   Value Q12CDYF
          -8  = "Inapplicable"
   ;
   Value Q12CMIF
          -8  = "Inapplicable"
   ;
   Value Q12CTMF
          -8  = "Inapplicable"
   ;
   Value Q12DDYF
          -8  = "Inapplicable"
   ;
   Value Q12DMIF
          -8  = "Inapplicable"
   ;
   Value Q12DTMF
          -8  = "Inapplicable"
   ;
   Value Q12EDYF
          -8  = "Inapplicable"
   ;
   Value Q12EMIF
          -8  = "Inapplicable"
   ;
   Value Q12ETMF
          -8  = "Inapplicable"
   ;
   Value Q12FDYF
          -8  = "Inapplicable"
   ;
   Value Q12FMIF
          -8  = "Inapplicable"
   ;
   Value Q12FTMF
          -8  = "Inapplicable"
   ;
   Value Q13ALNF
          -8  = "Inapplicable"
          -7  = "Varied length"
   ;
   Value Q13BLNF
          -8  = "Inapplicable"
          -7  = "Varied length"
   ;
   Value Q13CLNF
          -8  = "Inapplicable"
          -7  = "Varied length"
   ;
   Value Q13DAYF
          -8  = "Inapplicable"
          0  = "None"
          1  = "1 day"
          2  = "2 day"
          3  = "3 day"
          4  = "4 day"
          5  = "5 day"
          6  = "Varied by week"
   ;
   Value Q13DLNF
          -8  = "Inapplicable"
          -7  = "Varied length"
   ;
   Value Q13DR2F
          -8  = "Inapplicable"
          -6  = "Reported min per week for PE"
   ;
   Value Q13ELNF
          -8  = "Inapplicable"
          -7  = "Varied length"
   ;
   Value Q13FLNF
          -8  = "Inapplicable"
          -7  = "Varied length"
   ;
   Value Q14AF
          1  = "Yes"
          2  = "No"
   ;
   Value Q14BF
          1  = "Yes"
          2  = "No"
   ;
   Value Q14CF
          1  = "Yes"
          2  = "No"
   ;
   Value Q14DF
          1  = "Yes"
          2  = "No"
   ;
   Value Q14EF
          1  = "Yes"
          2  = "No"
   ;
   Value Q15AC1F
          1  = "Never"
          2  = "Selected grades"
          3  = "Yearly for all"
          4  = "Other approach"
   ;
   Value Q15AC2F
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q15BC1F
          1  = "Never"
          2  = "Selected grades"
          3  = "Yearly for all"
          4  = "Other approach"
   ;
   Value Q15BC2F
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q15CC1F
          1  = "Never"
          2  = "Selected grades"
          3  = "Yearly for all"
          4  = "Other approach"
   ;
   Value Q15CC2F
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q16F
          -9  = "Not ascertained"
   ;
   Value Q17F
          1  = "Circled"
          2  = "Not Circled"
   ;
   Value Q1F
          1  = "Yes"
          2  = "No"
   ;
   Value Q2F
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q3AF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q3BF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q3CF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q3DF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q3EF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q3FF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q3GF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q3HF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q3IF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q3JF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q3KF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q3LF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q3MF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q3NF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q3OF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q4DURIF
          -8  = "Inapplicable"
          1  = "Circled"
          2  = "Not circled"
   ;
   Value Q4MEALF
          -8  = "Inapplicable"
          1  = "Circled"
          2  = "Not circled"
   ;
   Value Q4NEVEF
          1  = "Circled"
          2  = "Not circled"
   ;
   Value Q4OTHF
          -8  = "Inapplicable"
          1  = "Circled"
          2  = "Not circled"
   ;
   Value Q4OUTF
          -8  = "Inapplicable"
          1  = "Circled"
          2  = "Not Circled"
   ;
   Value Q5AF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q5BF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q5CF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q5DF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q5EF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q5FF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q5GF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q5HF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q5IF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q6DURIF
          -8  = "Inapplicable"
          1  = "Circled"
          2  = "Not circled"
   ;
   Value Q6MEALF
          -8  = "Inapplicable"
          1  = "Circled"
          2  = "Not circled"
   ;
   Value Q6NEVEF
          1  = "Circled"
          2  = "Not circled"
   ;
   Value Q6OTHF
          -8  = "Inapplicable"
          1  = "Circled"
          2  = "Not circled"
   ;
   Value Q6OUTSF
          -8  = "Inapplicable"
          1  = "Circled"
          2  = "Not circled"
   ;
   Value Q7AF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q7BF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q7CF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q7DF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q7EF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q7FF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q7GF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q7HF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q7IF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q8F
          1  = "Yes"
          2  = "No"
          3  = "Don�t know"
   ;
   Value Q9AF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
          3  = "Don�t know"
   ;
   Value Q9BF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
          3  = "Don�t know"
   ;
   Value Q9CF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
          3  = "Don�t know"
   ;
   Value URBF
          0  = "(MISSING URBAN)"
          1  = "CITY"
          2  = "URBAN FRINGE"
          3  = "TOWN"
          4  = "RURAL"
   ;
   Value YESNOF
          1  = "Yes"
          2  = "No"
   ;
RUN;
