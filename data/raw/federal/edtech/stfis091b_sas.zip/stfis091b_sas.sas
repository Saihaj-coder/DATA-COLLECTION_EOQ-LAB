libname in 'G:\Public Use\Survey Data\CCD\State Fiscal (NPEFS)\NPEFS09\version 1b';
*****************************************************************************************;
*       PROGRAM: STFIS091b_SAS.sas                                                      *;
*          NOTE: 1) This program reads in the State Fiscal tab-delimited text data      *;
*                   file.                                                               *;
*                2) To create a permanent SAS data set, add a LIBNAME statement and     *;
*                   add the LIBNAME to the DATA statement.                              *;
*                3) Modify the path in the INFILE statement below to point to the       *;
*                   location of the text data file.                                     *;
*                4) Refer to the record layout file for detailed description of the     *;
*                   data elements, variable and value labels                            *;
*   PROVIDED BY: National Center for Education Statistics                               *;
*   LAST UPDATED: November 15, 2012                                                         *;
*****************************************************************************************;
      data in.stfis091b                          ;
     %let _EFIERR_ = 0; /* set the ERROR detection macro variable */
     infile 'G:\Public Use\Survey Data\CCD\State Fiscal (NPEFS)\NPEFS09\version 1b\stfis091b.txt'
 delimiter='09'x MISSOVER DSD lrecl=32767 firstobs=2 ;

        informat SURVYEAR best32. ;
        informat FIPS best32. ;
        informat STABR $2. ;
        informat STNAME $25. ;
        informat R1A best32. ;
        informat R1B best32. ;
        informat R1C best32. ;
        informat R1D best32. ;
        informat R1E best32. ;
        informat R1F best32. ;
        informat R1G best32. ;
        informat R1H best32. ;
        informat R1I best32. ;
        informat R1J best32. ;
        informat R1K best32. ;
        informat R1L best32. ;
        informat R1M best32. ;
        informat R1N best32. ;
        informat STR1 best32. ;
        informat R2 best32. ;
        informat R3 best32. ;
        informat R4A best32. ;
        informat R4B best32. ;
        informat R4C best32. ;
        informat R4D best32. ;
        informat STR4 best32. ;
        informat R5 best32. ;
        informat TR best32. ;
        informat E11 best32. ;
        informat E12 best32. ;
        informat E13 best32. ;
        informat E14 best32. ;
        informat E15 best32. ;
        informat E16 best32. ;
        informat E17 best32. ;
        informat E18 best32. ;
        informat STE1 best32. ;
        informat E11A best32. ;
        informat E11B best32. ;
        informat E11C best32. ;
        informat E11D best32. ;
        informat E2 best32. ;
        informat E212 best32. ;
        informat E213 best32. ;
        informat E214 best32. ;
        informat E215 best32. ;
        informat E216 best32. ;
        informat E217 best32. ;
        informat E218 best32. ;
        informat TE21 best32. ;
        informat E222 best32. ;
        informat E223 best32. ;
        informat E224 best32. ;
        informat E225 best32. ;
        informat E226 best32. ;
        informat E227 best32. ;
        informat E228 best32. ;
        informat TE22 best32. ;
        informat E232 best32. ;
        informat E233 best32. ;
        informat E234 best32. ;
        informat E235 best32. ;
        informat E236 best32. ;
        informat E237 best32. ;
        informat E238 best32. ;
        informat TE23 best32. ;
        informat E242 best32. ;
        informat E243 best32. ;
        informat E244 best32. ;
        informat E245 best32. ;
        informat E246 best32. ;
        informat E247 best32. ;
        informat E248 best32. ;
        informat TE24 best32. ;
        informat E252 best32. ;
        informat E253 best32. ;
        informat E254 best32. ;
        informat E255 best32. ;
        informat E256 best32. ;
        informat E257 best32. ;
        informat E258 best32. ;
        informat TE25 best32. ;
        informat E262 best32. ;
        informat E263 best32. ;
        informat E264 best32. ;
        informat E265 best32. ;
        informat E266 best32. ;
        informat E267 best32. ;
        informat E268 best32. ;
        informat TE26 best32. ;
        informat STE22 best32. ;
        informat STE23 best32. ;
        informat STE24 best32. ;
        informat STE25 best32. ;
        informat STE26 best32. ;
        informat STE27 best32. ;
        informat STE28 best32. ;
        informat STE2T best32. ;
        informat E3A11 best32. ;
        informat E3A12 best32. ;
        informat E3A13 best32. ;
        informat E3A14 best32. ;
        informat E3A2 best32. ;
        informat E3A16 best32. ;
        informat E3A1 best32. ;
        informat E3B11 best32. ;
        informat E3B12 best32. ;
        informat E3B13 best32. ;
        informat E3B14 best32. ;
        informat E3B2 best32. ;
        informat E3B16 best32. ;
        informat E3B1 best32. ;
        informat STE3 best32. ;
        informat E4A1 best32. ;
        informat E4A2 best32. ;
        informat E4B1 best32. ;
        informat E4B2 best32. ;
        informat E4C1 best32. ;
        informat E4C2 best32. ;
        informat E4D best32. ;
        informat E4E1 best32. ;
        informat E4E2 best32. ;
        informat STE4 best32. ;
        informat TE5 best32. ;
        informat E61 best32. ;
        informat E62 best32. ;
        informat E63 best32. ;
        informat STE6 best32. ;
        informat E7A1 best32. ;
        informat E7A2 best32. ;
        informat STE7 best32. ;
        informat E81 best32. ;
        informat E82 best32. ;
        informat E9A best32. ;
        informat E9B best32. ;
        informat E9C best32. ;
        informat E9D best32. ;
        informat E91 best32. ;
        informat STE9 best32. ;
        informat TE10 best32. ;
        informat TE11 best32. ;
        informat X12C best32. ;
        informat X12D best32. ;
        informat X12E best32. ;
        informat X12F best32. ;
        informat TX12 best32. ;
        informat NCE13 best32. ;
        informat ADA best32. ;
        informat A14A best32. ;
        informat A14B best32. ;
        informat PPE15 best32. ;
        informat MEMBR08 best32. ;
        informat ARRASTE1 best32. ;
        informat ARRATE5 best32. ;
        informat ARRAE81Z best32. ;
        informat ARRATE10 best32. ;
        informat ARRASTE6 best32. ;
        informat ARRATLEIZ best32. ;
        informat ARRASTE4 best32. ;
        informat IR1A $1. ;
        informat IR1B $1. ;
        informat IR1C $1. ;
        informat IR1D $1. ;
        informat IR1E $1. ;
        informat IR1F $1. ;
        informat IR1G $1. ;
        informat IR1H $1. ;
        informat IR1I $1. ;
        informat IR1J $1. ;
        informat IR1K $1. ;
        informat IR1L $1. ;
        informat IR1M $1. ;
        informat IR1N $1. ;
        informat ISTR1 $1. ;
        informat IR2 $1. ;
        informat IR3 $1. ;
        informat IR4A $1. ;
        informat IR4B $1. ;
        informat IR4C $1. ;
        informat IR4D $1. ;
        informat ISTR4 $1. ;
        informat IR5 $1. ;
        informat ITR $1. ;
        informat IE11 $1. ;
        informat IE12 $1. ;
        informat IE13 $1. ;
        informat IE14 $1. ;
        informat IE15 $1. ;
        informat IE16 $1. ;
        informat IE17 $1. ;
        informat IE18 $1. ;
        informat ISTE1 $1. ;
        informat IE11A $1. ;
        informat IE11B $1. ;
        informat IE11C $1. ;
        informat IE11D $1. ;
        informat IE2 $1. ;
        informat IE212 $1. ;
        informat IE213 $1. ;
        informat IE214 $1. ;
        informat IE215 $1. ;
        informat IE216 $1. ;
        informat IE217 $1. ;
        informat IE218 $1. ;
        informat ITE21 $1. ;
        informat IE222 $1. ;
        informat IE223 $1. ;
        informat IE224 $1. ;
        informat IE225 $1. ;
        informat IE226 $1. ;
        informat IE227 $1. ;
        informat IE228 $1. ;
        informat ITE22 $1. ;
        informat IE232 $1. ;
        informat IE233 $1. ;
        informat IE234 $1. ;
        informat IE235 $1. ;
        informat IE236 $1. ;
        informat IE237 $1. ;
        informat IE238 $1. ;
        informat ITE23 $1. ;
        informat IE242 $1. ;
        informat IE243 $1. ;
        informat IE244 $1. ;
        informat IE245 $1. ;
        informat IE246 $1. ;
        informat IE247 $1. ;
        informat IE248 $1. ;
        informat ITE24 $1. ;
        informat IE252 $1. ;
        informat IE253 $1. ;
        informat IE254 $1. ;
        informat IE255 $1. ;
        informat IE256 $1. ;
        informat IE257 $1. ;
        informat IE258 $1. ;
        informat ITE25 $1. ;
        informat IE262 $1. ;
        informat IE263 $1. ;
        informat IE264 $1. ;
        informat IE265 $1. ;
        informat IE266 $1. ;
        informat IE267 $1. ;
        informat IE268 $1. ;
        informat ITE26 $1. ;
        informat ISTE22 $1. ;
        informat ISTE23 $1. ;
        informat ISTE24 $1. ;
        informat ISTE25 $1. ;
        informat ISTE26 $1. ;
        informat ISTE27 $1. ;
        informat ISTE28 $1. ;
        informat ISTE2T $1. ;
        informat IE3A11 $1. ;
        informat IE3A12 $1. ;
        informat IE3A13 $1. ;
        informat IE3A14 $1. ;
        informat IE3A2 $1. ;
        informat IE3A16 $1. ;
        informat IE3A1 $1. ;
        informat IE3B11 $1. ;
        informat IE3B12 $1. ;
        informat IE3B13 $1. ;
        informat IE3B14 $1. ;
        informat IE3B2 $1. ;
        informat IE3B16 $1. ;
        informat IE3B1 $1. ;
        informat ISTE3 $1. ;
        informat IE4A1 $1. ;
        informat IE4A2 $1. ;
        informat IE4B1 $1. ;
        informat IE4B2 $1. ;
        informat IE4C1 $1. ;
        informat IE4C2 $1. ;
        informat IE4D $1. ;
        informat IE4E1 $1. ;
        informat IE4E2 $1. ;
        informat ISTE4 $1. ;
        informat ITE5 $1. ;
        informat IE61 $1. ;
        informat IE62 $1. ;
        informat IE63 $1. ;
        informat ISTE6 $1. ;
        informat IE7A1 $1. ;
        informat IE7A2 $1. ;
        informat ISTE7 $1. ;
        informat IE81 $1. ;
        informat IE82 $1. ;
        informat IE9A $1. ;
        informat IE9B $1. ;
        informat IE9C $1. ;
        informat IE9D $1. ;
        informat IE91 $1. ;
        informat ISTE9 $1. ;
        informat ITE10 $1. ;
        informat ITE11 $1. ;
        informat IX12C $1. ;
        informat IX12D $1. ;
        informat IX12E $1. ;
        informat IX12F $1. ;
        informat ITX12 $1. ;
        informat INCE13 $1. ;
        informat IADA $1. ;
        informat IA14A $1. ;
        informat IA14B $1. ;
        informat IPPE15 $1. ;
        informat IMEMBR08 $1. ;
        informat IARRASTE1 $1. ;
        informat IARRATE5 $1. ;
        informat IARRAE81Z $1. ;
        informat IARRATE10 $1. ;
        informat IARRASTE6 $1. ;
        informat IARRATLEIZ $1. ;
        informat IARRASTE4 $1. ;

        format SURVYEAR best12. ;
        format FIPS best12. ;
        format STABR $2. ;
        format STNAME $25. ;
        format R1A best12. ;
        format R1B best12. ;
        format R1C best12. ;
        format R1D best12. ;
        format R1E best12. ;
        format R1F best12. ;
        format R1G best12. ;
        format R1H best12. ;
        format R1I best12. ;
        format R1J best12. ;
        format R1K best12. ;
        format R1L best12. ;
        format R1M best12. ;
        format R1N best12. ;
        format STR1 best12. ;
        format R2 best12. ;
        format R3 best12. ;
        format R4A best12. ;
        format R4B best12. ;
        format R4C best12. ;
        format R4D best12. ;
        format STR4 best12. ;
        format R5 best12. ;
        format TR best12. ;
        format E11 best12. ;
        format E12 best12. ;
        format E13 best12. ;
        format E14 best12. ;
        format E15 best12. ;
        format E16 best12. ;
        format E17 best12. ;
        format E18 best12. ;
        format STE1 best12. ;
        format E11A best12. ;
        format E11B best12. ;
        format E11C best12. ;
        format E11D best12. ;
        format E2 best12. ;
        format E212 best12. ;
        format E213 best12. ;
        format E214 best12. ;
        format E215 best12. ;
        format E216 best12. ;
        format E217 best12. ;
        format E218 best12. ;
        format TE21 best12. ;
        format E222 best12. ;
        format E223 best12. ;
        format E224 best12. ;
        format E225 best12. ;
        format E226 best12. ;
        format E227 best12. ;
        format E228 best12. ;
        format TE22 best12. ;
        format E232 best12. ;
        format E233 best12. ;
        format E234 best12. ;
        format E235 best12. ;
        format E236 best12. ;
        format E237 best12. ;
        format E238 best12. ;
        format TE23 best12. ;
        format E242 best12. ;
        format E243 best12. ;
        format E244 best12. ;
        format E245 best12. ;
        format E246 best12. ;
        format E247 best12. ;
        format E248 best12. ;
        format TE24 best12. ;
        format E252 best12. ;
        format E253 best12. ;
        format E254 best12. ;
        format E255 best12. ;
        format E256 best12. ;
        format E257 best12. ;
        format E258 best12. ;
        format TE25 best12. ;
        format E262 best12. ;
        format E263 best12. ;
        format E264 best12. ;
        format E265 best12. ;
        format E266 best12. ;
        format E267 best12. ;
        format E268 best12. ;
        format TE26 best12. ;
        format STE22 best12. ;
        format STE23 best12. ;
        format STE24 best12. ;
        format STE25 best12. ;
        format STE26 best12. ;
        format STE27 best12. ;
        format STE28 best12. ;
        format STE2T best12. ;
        format E3A11 best12. ;
        format E3A12 best12. ;
        format E3A13 best12. ;
        format E3A14 best12. ;
        format E3A2 best12. ;
        format E3A16 best12. ;
        format E3A1 best12. ;
        format E3B11 best12. ;
        format E3B12 best12. ;
        format E3B13 best12. ;
        format E3B14 best12. ;
        format E3B2 best12. ;
        format E3B16 best12. ;
        format E3B1 best12. ;
        format STE3 best12. ;
        format E4A1 best12. ;
        format E4A2 best12. ;
        format E4B1 best12. ;
        format E4B2 best12. ;
        format E4C1 best12. ;
        format E4C2 best12. ;
        format E4D best12. ;
        format E4E1 best12. ;
        format E4E2 best12. ;
        format STE4 best12. ;
        format TE5 best12. ;
        format E61 best12. ;
        format E62 best12. ;
        format E63 best12. ;
        format STE6 best12. ;
        format E7A1 best12. ;
        format E7A2 best12. ;
        format STE7 best12. ;
        format E81 best12. ;
        format E82 best12. ;
        format E9A best12. ;
        format E9B best12. ;
        format E9C best12. ;
        format E9D best12. ;
        format E91 best12. ;
        format STE9 best12. ;
        format TE10 best12. ;
        format TE11 best12. ;
        format X12C best12. ;
        format X12D best12. ;
        format X12E best12. ;
        format X12F best12. ;
        format TX12 best12. ;
        format NCE13 best12. ;
        format ADA best12. ;
        format A14A best12. ;
        format A14B best12. ;
        format PPE15 best12. ;
        format MEMBR08 best12. ;
        format ARRASTE1 best12. ;
        format ARRATE5 best12. ;
        format ARRAE81Z best12. ;
        format ARRATE10 best12. ;
        format ARRASTE6 best12. ;
        format ARRATLEIZ best12. ;
        format ARRASTE4 best12. ;
        format IR1A $1. ;
        format IR1B $1. ;
        format IR1C $1. ;
        format IR1D $1. ;
        format IR1E $1. ;
        format IR1F $1. ;
        format IR1G $1. ;
        format IR1H $1. ;
        format IR1I $1. ;
        format IR1J $1. ;
        format IR1K $1. ;
        format IR1L $1. ;
        format IR1M $1. ;
        format IR1N $1. ;
        format ISTR1 $1. ;
        format IR2 $1. ;
        format IR3 $1. ;
        format IR4A $1. ;
        format IR4B $1. ;
        format IR4C $1. ;
        format IR4D $1. ;
        format ISTR4 $1. ;
        format IR5 $1. ;
        format ITR $1. ;
        format IE11 $1. ;
        format IE12 $1. ;
        format IE13 $1. ;
        format IE14 $1. ;
        format IE15 $1. ;
        format IE16 $1. ;
        format IE17 $1. ;
        format IE18 $1. ;
        format ISTE1 $1. ;
        format IE11A $1. ;
        format IE11B $1. ;
        format IE11C $1. ;
        format IE11D $1. ;
        format IE2 $1. ;
        format IE212 $1. ;
        format IE213 $1. ;
        format IE214 $1. ;
        format IE215 $1. ;
        format IE216 $1. ;
        format IE217 $1. ;
        format IE218 $1. ;
        format ITE21 $1. ;
        format IE222 $1. ;
        format IE223 $1. ;
        format IE224 $1. ;
        format IE225 $1. ;
        format IE226 $1. ;
        format IE227 $1. ;
        format IE228 $1. ;
        format ITE22 $1. ;
        format IE232 $1. ;
        format IE233 $1. ;
        format IE234 $1. ;
        format IE235 $1. ;
        format IE236 $1. ;
        format IE237 $1. ;
        format IE238 $1. ;
        format ITE23 $1. ;
        format IE242 $1. ;
        format IE243 $1. ;
        format IE244 $1. ;
        format IE245 $1. ;
        format IE246 $1. ;
        format IE247 $1. ;
        format IE248 $1. ;
        format ITE24 $1. ;
        format IE252 $1. ;
        format IE253 $1. ;
        format IE254 $1. ;
        format IE255 $1. ;
        format IE256 $1. ;
        format IE257 $1. ;
        format IE258 $1. ;
        format ITE25 $1. ;
        format IE262 $1. ;
        format IE263 $1. ;
        format IE264 $1. ;
        format IE265 $1. ;
        format IE266 $1. ;
        format IE267 $1. ;
        format IE268 $1. ;
        format ITE26 $1. ;
        format ISTE22 $1. ;
        format ISTE23 $1. ;
        format ISTE24 $1. ;
        format ISTE25 $1. ;
        format ISTE26 $1. ;
        format ISTE27 $1. ;
        format ISTE28 $1. ;
        format ISTE2T $1. ;
        format IE3A11 $1. ;
        format IE3A12 $1. ;
        format IE3A13 $1. ;
        format IE3A14 $1. ;
        format IE3A2 $1. ;
        format IE3A16 $1. ;
        format IE3A1 $1. ;
        format IE3B11 $1. ;
        format IE3B12 $1. ;
        format IE3B13 $1. ;
        format IE3B14 $1. ;
        format IE3B2 $1. ;
        format IE3B16 $1. ;
        format IE3B1 $1. ;
        format ISTE3 $1. ;
        format IE4A1 $1. ;
        format IE4A2 $1. ;
        format IE4B1 $1. ;
        format IE4B2 $1. ;
        format IE4C1 $1. ;
        format IE4C2 $1. ;
        format IE4D $1. ;
        format IE4E1 $1. ;
        format IE4E2 $1. ;
        format ISTE4 $1. ;
        format ITE5 $1. ;
        format IE61 $1. ;
        format IE62 $1. ;
        format IE63 $1. ;
        format ISTE6 $1. ;
        format IE7A1 $1. ;
        format IE7A2 $1. ;
        format ISTE7 $1. ;
        format IE81 $1. ;
        format IE82 $1. ;
        format IE9A $1. ;
        format IE9B $1. ;
        format IE9C $1. ;
        format IE9D $1. ;
        format IE91 $1. ;
        format ISTE9 $1. ;
        format ITE10 $1. ;
        format ITE11 $1. ;
        format IX12C $1. ;
        format IX12D $1. ;
        format IX12E $1. ;
        format IX12F $1. ;
        format ITX12 $1. ;
        format INCE13 $1. ;
        format IADA $1. ;
        format IA14A $1. ;
        format IA14B $1. ;
        format IPPE15 $1. ;
        format IMEMBR08 $1. ;
        format IARRASTE1 $1. ;
        format IARRATE5 $1. ;
        format IARRAE81Z $1. ;
        format IARRATE10 $1. ;
        format IARRASTE6 $1. ;
        format IARRATLEIZ $1. ;
        format IARRASTE4 $1. ;
     input
                 SURVYEAR
                 FIPS
                 STABR $
                 STNAME $
                 R1A
                 R1B
                 R1C
                 R1D
                 R1E
                 R1F
                 R1G
                 R1H
                 R1I
                 R1J
                 R1K
                 R1L
                 R1M
                 R1N
                 STR1
                 R2
                 R3
                 R4A
                 R4B
                 R4C
                 R4D
                 STR4
                 R5
                 TR
                 E11
                 E12
                 E13
                 E14
                 E15
                 E16
                 E17
                 E18
                 STE1
                 E11A
                 E11B
                 E11C
                 E11D
                 E2
                 E212
                 E213
                 E214
                 E215
                 E216
                 E217
                 E218
                 TE21
                 E222
                 E223
                 E224
                 E225
                 E226
                 E227
                 E228
                 TE22
                 E232
                 E233
                 E234
                 E235
                 E236
                 E237
                 E238
                 TE23
                 E242
                 E243
                 E244
                 E245
                 E246
                 E247
                 E248
                 TE24
                 E252
                 E253
                 E254
                 E255
                 E256
                 E257
                 E258
                 TE25
                 E262
                 E263
                 E264
                 E265
                 E266
                 E267
                 E268
                 TE26
                 STE22
                 STE23
                 STE24
                 STE25
                 STE26
                 STE27
                 STE28
                 STE2T
                 E3A11
                 E3A12
                 E3A13
                 E3A14
                 E3A2
                 E3A16
                 E3A1
                 E3B11
                 E3B12
                 E3B13
                 E3B14
                 E3B2
                 E3B16
                 E3B1
                 STE3
                 E4A1
                 E4A2
                 E4B1
                 E4B2
                 E4C1
                 E4C2
                 E4D
                 E4E1
                 E4E2
                 STE4
                 TE5
                 E61
                 E62
                 E63
                 STE6
                 E7A1
                 E7A2
                 STE7
                 E81
                 E82
                 E9A
                 E9B
                 E9C
                 E9D
                 E91
                 STE9
                 TE10
                 TE11
                 X12C
                 X12D
                 X12E
                 X12F
                 TX12
                 NCE13
                 ADA
                 A14A
                 A14B
                 PPE15
                 MEMBR08
                 ARRASTE1
                 ARRATE5
                 ARRAE81Z
                 ARRATE10
                 ARRASTE6
                 ARRATLEIZ
                 ARRASTE4
                 IR1A $
                 IR1B $
                 IR1C $
                 IR1D $
                 IR1E $
                 IR1F $
                 IR1G $
                 IR1H $
                 IR1I $
                 IR1J $
                 IR1K $
                 IR1L $
                 IR1M $
                 IR1N $
                 ISTR1 $
                 IR2 $
                 IR3 $
                 IR4A $
                 IR4B $
                 IR4C $
                 IR4D $
                 ISTR4 $
                 IR5 $
                 ITR $
                 IE11 $
                 IE12 $
                 IE13 $
                 IE14 $
                 IE15 $
                 IE16 $
                 IE17 $
                 IE18 $
                 ISTE1 $
                 IE11A $
                 IE11B $
                 IE11C $
                 IE11D $
                 IE2 $
                 IE212 $
                 IE213 $
                 IE214 $
                 IE215 $
                 IE216 $
                 IE217 $
                 IE218 $
                 ITE21 $
                 IE222 $
                 IE223 $
                 IE224 $
                 IE225 $
                 IE226 $
                 IE227 $
                 IE228 $
                 ITE22 $
                 IE232 $
                 IE233 $
                 IE234 $
                 IE235 $
                 IE236 $
                 IE237 $
                 IE238 $
                 ITE23 $
                 IE242 $
                 IE243 $
                 IE244 $
                 IE245 $
                 IE246 $
                 IE247 $
                 IE248 $
                 ITE24 $
                 IE252 $
                 IE253 $
                 IE254 $
                 IE255 $
                 IE256 $
                 IE257 $
                 IE258 $
                 ITE25 $
                 IE262 $
                 IE263 $
                 IE264 $
                 IE265 $
                 IE266 $
                 IE267 $
                 IE268 $
                 ITE26 $
                 ISTE22 $
                 ISTE23 $
                 ISTE24 $
                 ISTE25 $
                 ISTE26 $
                 ISTE27 $
                 ISTE28 $
                 ISTE2T $
                 IE3A11 $
                 IE3A12 $
                 IE3A13 $
                 IE3A14 $
                 IE3A2 $
                 IE3A16 $
                 IE3A1 $
                 IE3B11 $
                 IE3B12 $
                 IE3B13 $
                 IE3B14 $
                 IE3B2 $
                 IE3B16 $
                 IE3B1 $
                 ISTE3 $
                 IE4A1 $
                 IE4A2 $
                 IE4B1 $
                 IE4B2 $
                 IE4C1 $
                 IE4C2 $
                 IE4D $
                 IE4E1 $
                 IE4E2 $
                 ISTE4 $
                 ITE5 $
                 IE61 $
                 IE62 $
                 IE63 $
                 ISTE6 $
                 IE7A1 $
                 IE7A2 $
                 ISTE7 $
                 IE81 $
                 IE82 $
                 IE9A $
                 IE9B $
                 IE9C $
                 IE9D $
                 IE91 $
                 ISTE9 $
                 ITE10 $
                 ITE11 $
                 IX12C $
                 IX12D $
                 IX12E $
                 IX12F $
                 ITX12 $
                 INCE13 $
                 IADA $
                 IA14A $
                 IA14B $
                 IPPE15 $
                 IMEMBR08 $
                 IARRASTE1 $
                 IARRATE5 $
                 IARRAE81Z $
                 IARRATE10 $
                 IARRASTE6 $
                 IARRATLEIZ $
                 IARRASTE4 $
     ;
     if _ERROR_ then call symputx('_EFIERR_',1);  /* set ERROR detection macro variable */
     run;


