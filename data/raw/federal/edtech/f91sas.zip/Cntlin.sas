PROC Format;
   Value FLAGF
          0  = "Not imputed"
          1  = "Imputed"
   ;
   Value FREELF
          1  = "Less than 35 percent"
          2  = "35 to 49 percent"
          3  = "50 to 74 percent"
          4  = "75 percent or more"
   ;
   Value GRADEF
          -8  = "INAPPLICABLE"
          1  = "No grade higher than 6"
          2  = "At least one grade higher than 6"
   ;
   Value INAPLICF
          -8  = "INAPLICABLE"
   ;
   Value MINSTF
          1  = "Less than 6%"
          2  = "6% to 20%"
          3  = "21% to 49%"
          4  = "50% or more"
   ;
   Value Q10F
          -8  = "INAPPLICABLE"
          1  = "Yes"
          2  = "No"
   ;
   Value Q11F
          1  = "Yes"
          2  = "No"
   ;
   Value Q14F
          -8  = "INAPPLICABLE"
          1  = "Yes, for all students"
          2  = "Yes, for some students"
          3  = "No"
   ;
   Value Q15F
          -8  = "INAPPLICABLE"
          1  = "Yes"
          2  = "No"
   ;
   Value Q16AF
          -8  = "INAPPLICABLE"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Large extent"
   ;
   Value Q16BF
          -8  = "INAPPLICABLE"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Large extent"
   ;
   Value Q17F
          1  = "Yes"
          2  = "No"
   ;
   Value Q19ABROF
          -8  = "INAPPLICABLE"
          1  = "Yes"
          2  = "No"
   ;
   Value Q19AFOCF
          -8  = "INAPPLICABLE"
          1  = "Yes"
          2  = "No"
   ;
   Value Q19ASTAF
          -8  = "INAPPLICABLE"
          1  = "Yes"
          2  = "No"
   ;
   Value Q19BBROF
          -8  = "INAPPLICABLE"
          1  = "Yes"
          2  = "No"
   ;
   Value Q19BFOCF
          -8  = "INAPPLICABLE"
          1  = "Yes"
          2  = "No"
   ;
   Value Q19BSTAF
          -8  = "INAPPLICABLE"
          1  = "Yes"
          2  = "No"
   ;
   Value Q19CBROF
          -8  = "INAPPLICABLE"
          1  = "Yes"
          2  = "No"
   ;
   Value Q19CFOCF
          -8  = "INAPPLICABLE"
          1  = "Yes"
          2  = "No"
   ;
   Value Q19CSTAF
          -8  = "INAPPLICABLE"
          1  = "Yes"
          2  = "No"
   ;
   Value Q19DBROF
          -8  = "INAPPLICABLE"
          1  = "Yes"
          2  = "No"
   ;
   Value Q19DFOCF
          -8  = "INAPPLICABLE"
          1  = "Yes"
          2  = "No"
   ;
   Value Q19DSTAF
          -8  = "INAPPLICABLE"
          1  = "Yes"
          2  = "No"
   ;
   Value Q19EBROF
          -8  = "INAPPLICABLE"
          1  = "Yes"
          2  = "No"
   ;
   Value Q19EFOCF
          -8  = "INAPPLICABLE"
          1  = "Yes"
          2  = "No"
   ;
   Value Q19FBROF
          -8  = "INAPPLICABLE"
          1  = "Yes"
          2  = "No"
   ;
   Value Q19FFOCF
          -8  = "INAPPLICABLE"
          1  = "Yes"
          2  = "No"
   ;
   Value Q19FSTAF
          -8  = "INAPPLICABLE"
          1  = "Yes"
          2  = "No"
   ;
   Value Q1F
          1  = "Yes"
          2  = "No"
   ;
   Value Q20F
          -8  = "INAPPLICABLE"
          1  = "Yes"
          2  = "No"
   ;
   Value Q21F
          -8  = "INAPPLICABLE"
          1  = "Yes, for all students"
          2  = "Yes, for some students"
          3  = "No"
   ;
   Value Q22AF
          -8  = "INAPPLICABLE"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Large extent"
   ;
   Value Q22BF
          -8  = "INAPPLICABLE"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Large extent"
   ;
   Value Q22CF
          -8  = "INAPPLICABLE"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Large extent"
   ;
   Value Q23AF
          1  = "Yes"
          2  = "No"
          3  = "Don�t know"
   ;
   Value Q23BF
          1  = "Yes"
          2  = "No"
          3  = "Don�t know"
   ;
   Value Q23CF
          1  = "Yes"
          2  = "No"
          3  = "Don�t know"
   ;
   Value Q23DF
          1  = "Yes"
          2  = "No"
          3  = "Don�t know"
   ;
   Value Q3F
          -8  = "INAPPLICABLE"
          1  = "Yes"
          2  = "No"
   ;
   Value Q4F
          -8  = "INAPPLICABLE"
          1  = "Yes, for all students"
          2  = "Yes, for some students"
          3  = "No"
   ;
   Value Q5F
          -8  = "INAPPLICABLE"
          1  = "Yes"
          2  = "No"
   ;
   Value Q6AF
          -8  = "INAPPLICABLE"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Large extent"
   ;
   Value Q6BF
          -8  = "INAPPLICABLE"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Large extent"
   ;
   Value Q6CF
          -8  = "INAPPLICABLE"
          1  = "Not at all"
          2  = "Small extent"
          3  = "Moderate extent"
          4  = "Large extent"
   ;
   Value Q7F
          1  = "Yes"
          2  = "No"
   ;
   Value Q8APGRMF
          -8  = "INAPPLICABLE"
          1  = "Yes"
          2  = "No"
   ;
   Value Q8BPGRMF
          -8  = "INAPPLICABLE"
          1  = "Yes"
          2  = "No"
   ;
   Value Q8CPGRMF
          -8  = "INAPPLICABLE"
          1  = "Yes"
          2  = "No"
   ;
   Value Q9F
          -8  = "INAPPLICABLE"
          1  = "Yes, for all students"
          2  = "Yes, for some students"
          3  = "No"
   ;
   Value REGION
          1  = "Northeast"
          2  = "Southeast"
          3  = "Central"
          4  = "West"
   ;
   Value SIZEF
          1  = "Less than 300"
          2  = "300-499"
          3  = "500 or more"
   ;
   Value URBF
          1  = "City"
          2  = "Urban Fringe"
          3  = "Town"
          4  = "Rural"
   ;
RUN;
