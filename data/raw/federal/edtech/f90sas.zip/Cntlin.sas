PROC Format;
   Value FRELNCHF
          1  = "Less than 35 percent"
          2  = "35 to 49 percent"
          3  = "50 to 74 percent"
          4  = "75 percent or more"
   ;
   Value IFGF
          0  = "Not imputed"
          1  = "Imputed"
   ;
   Value MINSTF
          -9  = "Missing"
          1  = "Less than 6%"
          2  = "6-20%"
          3  = "21-49%"
          4  = "50% or more"
   ;
   Value OEREGF
          1  = "Northeast"
          2  = "Southeast"
          3  = "Central"
          4  = "West"
   ;
   Value Q10AF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q10BF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q11F
          -8  = "Inapplicable"
          0 - 350  = (|3.|)
   ;
   Value Q12AF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q12BF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q12CF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q12DF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q12EF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q13F
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q14AF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q14BF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q14CF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q14DF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q14EF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q14FF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q14GF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q14HF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q15F
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q16AF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q16BF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q16CF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q16DF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q16EF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q16FF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q16GF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q17F
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q18F
          -8  = "Inapplicable"
          1  = "0 percent"
          2  = "1 to 25 percent"
          3  = "26 to 50 percent"
          4  = "51 to 75 percent"
          5  = "76 to 100 percent"
   ;
   Value Q19F
          1  = "Yes"
          2  = "No"
   ;
   Value Q20F
          -8  = "Inapplicable"
          1  = "Less than 1 week"
          2  = "1 week to less than 1 month"
          3  = "1 month to less than 3 months"
          4  = "3 months to less than 6 months"
          5  = "6 months to less than the entire school year"
          6  = "The entire school year"
          7  = "Other"
   ;
   Value Q21F
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q22F
          1  = "Yes"
          2  = "No"
   ;
   Value Q23F
          1  = "Yes"
          2  = "No"
   ;
   Value Q4F
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q5F
          -8  = "Inapplicable"
          1 - 2500  = (|4.|)
   ;
   Value Q6F
          -8  = "Inapplicable"
          0 - 2133  = (|4.|)
   ;
   Value Q7AF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q7BF
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q8F
          -8  = "Inapplicable"
          0 - 350  = (|3.|)
   ;
   Value Q9F
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value SIZEF
          1  = "Less than 300"
          2  = "300 to 999"
          3  = "1000 or more"
   ;
   Value SLEVELF
          -9  = "Missing"
          1  = "Elementary"
          2  = "Secondary"
   ;
   Value URBANF
          1  = "City"
          2  = "Urban fringe"
          3  = "Town"
          4  = "Rural"
   ;
RUN;
