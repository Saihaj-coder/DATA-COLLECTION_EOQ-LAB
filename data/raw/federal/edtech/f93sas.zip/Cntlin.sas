PROC Format;
   Value FLAGF
          0  = "Not imputed"
          1  = "Imputed"
   ;
   Value OEREGF
          1  = "Northeast"
          2  = "Southeast"
          3  = "Central"
          4  = "West"
   ;
   Value POVST2F
          -9  = "Not ascertained"
          1  = "Less than 10 percent"
          2  = "10-19 percent"
          3  = "20 percent or more"
   ;
   Value Q10AF
          1  = "Yes"
          2  = "No"
   ;
   Value Q10BF
          1  = "Yes"
          2  = "No"
   ;
   Value Q10CF
          1  = "Yes"
          2  = "No"
   ;
   Value Q10DF
          1  = "Yes"
          2  = "No"
   ;
   Value Q10EF
          1  = "Yes"
          2  = "No"
   ;
   Value Q10FF
          1  = "Yes"
          2  = "No"
   ;
   Value Q11APT1F
          -8  = "Inapplicable"
          1  = "Yes, to all elementary teachers"
          2  = "Yes, to some elementary teachers"
          3  = "No"
   ;
   Value Q11APT2F
          -8  = "Inapplicable"
          1  = "Yes, to all secondary teachers"
          2  = "Yes, to some secondary teachers"
          3  = "No"
   ;
   Value Q11BOX1F
          0  = "Not checked"
          1  = "Checked"
   ;
   Value Q11BOX2F
          0  = "Not checked"
          1  = "Checked"
   ;
   Value Q11BPT1F
          -8  = "Inapplicable"
          1  = "Yes, to all elementary teachers"
          2  = "Yes, to some elementary teachers"
          3  = "No"
   ;
   Value Q11BPT2F
          -8  = "Inapplicable"
          1  = "Yes, to all secondary teachers"
          2  = "Yes, to some secondary teachers"
          3  = "No"
   ;
   Value Q11CPT1F
          -8  = "Inapplicable"
          1  = "Yes, to all elementary teachers"
          2  = "Yes, to some elementary teachers"
          3  = "No"
   ;
   Value Q11CPT2F
          -8  = "Inapplicable"
          1  = "Yes, to all secondary teachers"
          2  = "Yes, to some secondary teachers"
          3  = "No"
   ;
   Value Q11DPT1F
          -8  = "Inapplicable"
          1  = "Yes, to all elementary teachers"
          2  = "Yes, to some elementary teachers"
          3  = "No"
   ;
   Value Q11DPT2F
          -8  = "Inapplicable"
          1  = "Yes, to all secondary teachers"
          2  = "Yes, to some secondary teachers"
          3  = "No"
   ;
   Value Q11EPT1F
          -8  = "Inapplicable"
          1  = "Yes, to all elementary teachers"
          2  = "Yes, to some elementary teachers"
          3  = "No"
   ;
   Value Q11EPT2F
          -8  = "Inapplicable"
          1  = "Yes, to all secondary teachers"
          2  = "Yes, to some secondary teachers"
          3  = "No"
   ;
   Value Q11FPT1F
          -8  = "Inapplicable"
          1  = "Yes, to all elementary teachers"
          2  = "Yes, to some elementary teachers"
          3  = "No"
   ;
   Value Q11FPT2F
          -8  = "Inapplicable"
          1  = "Yes, to all secondary teachers"
          2  = "Yes, to some secondary teachers"
          3  = "No"
   ;
   Value Q11GPT1F
          -8  = "Inapplicable"
          1  = "Yes, to all elementary teachers"
          2  = "Yes, to some elementary teachers"
          3  = "No"
   ;
   Value Q11GPT2F
          -8  = "Inapplicable"
          1  = "Yes, to all secondary teachers"
          2  = "Yes, to some secondary teachers"
          3  = "No"
   ;
   Value Q11HPT1F
          -8  = "Inapplicable"
          1  = "Yes, to all elementary teachers"
          2  = "Yes, to some elementary teachers"
          3  = "No"
   ;
   Value Q11HPT2F
          -8  = "Inapplicable"
          1  = "Yes, to all secondary teachers"
          2  = "Yes, to some secondary teachers"
          3  = "No"
   ;
   Value Q12APT1F
          -8  = "Inapplicable"
          1  = "Yes, to all elementary students"
          2  = "Yes, to some elementary students"
          3  = "No"
   ;
   Value Q12APT2F
          -8  = "Inapplicable"
          1  = "Yes, to all secondary students"
          2  = "Yes, to some secondary students"
          3  = "No"
   ;
   Value Q12BPT1F
          -8  = "Inapplicable"
          1  = "Yes, to all elementary students"
          2  = "Yes, to some elementary students"
          3  = "No"
   ;
   Value Q12BPT2F
          -8  = "Inapplicable"
          1  = "Yes, to all secondary students"
          2  = "Yes, to some secondary students"
          3  = "No"
   ;
   Value Q12CPT1F
          -8  = "Inapplicable"
          1  = "Yes, to all elementary students"
          2  = "Yes, to some elementary students"
          3  = "No"
   ;
   Value Q12CPT2F
          -8  = "Inapplicable"
          1  = "Yes, to all secondary students"
          2  = "Yes, to some secondary students"
          3  = "No"
   ;
   Value Q12DPT1F
          -8  = "Inapplicable"
          1  = "Yes, to all elementary students"
          2  = "Yes, to some elementary students"
          3  = "No"
   ;
   Value Q12DPT2F
          -8  = "Inapplicable"
          1  = "Yes, to all secondary students"
          2  = "Yes, to some secondary students"
          3  = "No"
   ;
   Value Q12EPT1F
          -8  = "Inapplicable"
          1  = "Yes, to all elementary students"
          2  = "Yes, to some elementary students"
          3  = "No"
   ;
   Value Q12EPT2F
          -8  = "Inapplicable"
          1  = "Yes, to all secondary students"
          2  = "Yes, to some secondary students"
          3  = "No"
   ;
   Value Q12FPT1F
          -8  = "Inapplicable"
          1  = "Yes, to all elementary students"
          2  = "Yes, to some elementary students"
          3  = "No"
   ;
   Value Q12FPT2F
          -8  = "Inapplicable"
          1  = "Yes, to all secondary students"
          2  = "Yes, to some secondary students"
          3  = "No"
   ;
   Value Q12GPT1F
          -8  = "Inapplicable"
          1  = "Yes, to all elementary students"
          2  = "Yes, to some elementary students"
          3  = "No"
   ;
   Value Q12GPT2F
          -8  = "Inapplicable"
          1  = "Yes, to all secondary students"
          2  = "Yes, to some secondary students"
          3  = "No"
   ;
   Value Q13AF
          1  = "Yes"
          2  = "No"
   ;
   Value Q13BF
          1  = "Yes"
          2  = "No"
   ;
   Value Q13CF
          1  = "Yes"
          2  = "No"
   ;
   Value Q13DF
          1  = "Yes"
          2  = "No"
   ;
   Value Q13EF
          1  = "Yes"
          2  = "No"
   ;
   Value Q13FF
          1  = "Yes"
          2  = "No"
   ;
   Value Q13GF
          1  = "Yes"
          2  = "No"
   ;
   Value Q13HF
          1  = "Yes"
          2  = "No"
   ;
   Value Q13IF
          1  = "Yes"
          2  = "No"
   ;
   Value Q13JF
          1  = "Yes"
          2  = "No"
   ;
   Value Q13KF
          1  = "Yes"
          2  = "No"
   ;
   Value Q13LF
          1  = "Yes"
          2  = "No"
   ;
   Value Q14F
          1  = "Yes, full-time devoted to this role"
          2  = "Yes, part-time devoted to this role"
          3  = "No"
   ;
   Value Q15APT1F
          1  = "Yes"
          2  = "No"
   ;
   Value Q15APT2F
          1  = "Yes"
          2  = "No"
   ;
   Value Q15BPT1F
          1  = "Yes"
          2  = "No"
   ;
   Value Q15BPT2F
          1  = "Yes"
          2  = "No"
   ;
   Value Q15CPT1F
          1  = "Yes"
          2  = "No"
   ;
   Value Q15CPT2F
          1  = "Yes"
          2  = "No"
   ;
   Value Q15DPT1F
          1  = "Yes"
          2  = "No"
   ;
   Value Q15DPT2F
          1  = "Yes"
          2  = "No"
   ;
   Value Q15EPT1F
          1  = "Yes"
          2  = "No"
   ;
   Value Q15EPT2F
          1  = "Yes"
          2  = "No"
   ;
   Value Q15FPT1F
          1  = "Yes"
          2  = "No"
   ;
   Value Q15FPT2F
          1  = "Yes"
          2  = "No"
   ;
   Value Q15GPT1F
          1  = "Yes"
          2  = "No"
   ;
   Value Q15GPT2F
          1  = "Yes"
          2  = "No"
   ;
   Value Q15HPT1F
          1  = "Yes"
          2  = "No"
   ;
   Value Q15HPT2F
          1  = "Yes"
          2  = "No"
   ;
   Value Q15IPT1F
          1  = "Yes"
          2  = "No"
   ;
   Value Q15IPT2F
          1  = "Yes"
          2  = "No"
   ;
   Value Q15JPT1F
          1  = "Yes"
          2  = "No"
   ;
   Value Q15JPT2F
          1  = "Yes"
          2  = "No"
   ;
   Value Q15KPT1F
          1  = "Yes"
          2  = "No"
   ;
   Value Q15KPT2F
          1  = "Yes"
          2  = "No"
   ;
   Value Q15LPT1F
          1  = "Yes"
          2  = "No"
   ;
   Value Q15LPT2F
          1  = "Yes"
          2  = "No"
   ;
   Value Q15MPT1F
          1  = "Yes"
          2  = "No"
   ;
   Value Q15MPT2F
          1  = "Yes"
          2  = "No"
   ;
   Value Q15NPT1F
          1  = "Yes"
          2  = "No"
   ;
   Value Q15NPT2F
          1  = "Yes"
          2  = "No"
   ;
   Value Q16AF
          1  = "Strongly disagree"
          2  = "Somewhat disagree"
          3  = "Neither agree nor disagree"
          4  = "Somewhat agree"
          5  = "Strongly agree"
   ;
   Value Q16BF
          1  = "Strongly disagree"
          2  = "Somewhat disagree"
          3  = "Neither agree nor disagree"
          4  = "Somewhat agree"
          5  = "Strongly agree"
   ;
   Value Q16CF
          1  = "Strongly disagree"
          2  = "Somewhat disagree"
          3  = "Neither agree nor disagree"
          4  = "Somewhat agree"
          5  = "Strongly agree"
   ;
   Value Q16DF
          1  = "Strongly disagree"
          2  = "Somewhat disagree"
          3  = "Neither agree nor disagree"
          4  = "Somewhat agree"
          5  = "Strongly agree"
   ;
   Value Q16EF
          1  = "Strongly disagree"
          2  = "Somewhat disagree"
          3  = "Neither agree nor disagree"
          4  = "Somewhat agree"
          5  = "Strongly agree"
   ;
   Value Q16FF
          1  = "Strongly disagree"
          2  = "Somewhat disagree"
          3  = "Neither agree nor disagree"
          4  = "Somewhat agree"
          5  = "Strongly agree"
   ;
   Value Q16GF
          1  = "Strongly disagree"
          2  = "Somewhat disagree"
          3  = "Neither agree nor disagree"
          4  = "Somewhat agree"
          5  = "Strongly agree"
   ;
   Value Q16HF
          1  = "Strongly disagree"
          2  = "Somewhat disagree"
          3  = "Neither agree nor disagree"
          4  = "Somewhat agree"
          5  = "Strongly agree"
   ;
   Value Q3F
          1  = "Yes"
          2  = "No (Skip to question 6.)"
   ;
   Value Q5APT2F
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q5BPT2F
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q5CPT2F
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q5DPT2F
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q5EPT2F
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q5FPT2F
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q5GPT2F
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q5HPT2F
          -8  = "Inapplicable"
          1  = "Yes"
          2  = "No"
   ;
   Value Q6F
          1  = "Yes"
          2  = "No"
   ;
   Value Q7F
          1  = "Yes"
          2  = "No"
   ;
   Value Q8F
          1  = "Yes, for all computers"
          2  = "Yes, for some computers"
          3  = "No"
   ;
   Value Q9AF
          1  = "Yes"
          2  = "No"
   ;
   Value Q9BF
          1  = "Yes"
          2  = "No"
   ;
   Value Q9CF
          1  = "Yes"
          2  = "No"
   ;
   Value Q9DF
          1  = "Yes"
          2  = "No"
   ;
   Value Q9EF
          1  = "Yes"
          2  = "No"
   ;
   Value Q9FF
          1  = "Yes"
          2  = "No"
   ;
   Value Q9GF
          1  = "Yes"
          2  = "No"
   ;
   Value RQ2CATF
          1  = "All schools have LAN"
          2  = "Some schools have LAN"
          3  = "No schools have LAN"
   ;
   Value RQ4CAT
          1  = "All schools have WAN"
          2  = "Some schools have WAN"
          3  = "No schools have WAN"
   ;
   Value R_Q5F
          -8  = "Inapplicable"
          0  = "0 percent"
          1  = "1 to 10 percent"
          2  = "11 to 25 percent"
          3  = "26 to 50 percent"
          4  = "51 to 75 percent"
          5  = "76 to 89 percent"
          6  = "90 to 99 percent"
          7  = "100 percent"
   ;
   Value SIZEF
          1  = "Less than 2,500"
          2  = "2,500-9,999"
          3  = "10,000 or more"
   ;
   Value URBANF
          1  = "City"
          2  = "Suburban"
          3  = "Town"
          4  = "Rural"
   ;
RUN;
