PROC Format;
   Value DISTSIZF
          1  = "Less than 2,500"
          2  = "2,500-9,999"
          3  = "10,000 or more"
   ;
   Value DLEADF
          -9  = "Not ascertained"
          1  = "Yes"
          2  = "No"
   ;
   Value FLAGF
          0  = "Not Imputed"
          1  = "Imputed"
   ;
   Value LEVELF
          1  = "Elementary"
          2  = "Secondary"
          3  = "Combined"
   ;
   Value MINSTF
          1  = "Less than 6 percent"
          2  = "6 to 20 percent"
          3  = "21 to 49 percent"
          4  = "50 percent or more"
   ;
   Value OEREGF
          1  = "Northeast"
          2  = "Southeast"
          3  = "Central"
          4  = "West"
   ;
   Value POVSTF
          1  = "Less than 35 percent"
          2  = "35 to 49 percent"
          3  = "50 to 74 percent"
          4  = "75 percent or more"
   ;
   Value Q10F
          1  = "0 hours (Skip to Q12.)"
          2  = "1-8 hours"
          3  = "9-16 hours"
          4  = "17-32 hours"
          5  = "33 hours or more"
   ;
   Value Q11AF
          -8  = "Inapplicable"
          1  = "Strongly disagree"
          2  = "Somewhat disagree"
          3  = "Somewhat agree"
          4  = "Strongly agree"
   ;
   Value Q11BF
          -8  = "Inapplicable"
          1  = "Strongly disagree"
          2  = "Somewhat disagree"
          3  = "Somewhat agree"
          4  = "Strongly agree"
   ;
   Value Q11CF
          -8  = "Inapplicable"
          1  = "Strongly disagree"
          2  = "Somewhat disagree"
          3  = "Somewhat agree"
          4  = "Strongly agree"
   ;
   Value Q11DF
          -8  = "Inapplicable"
          1  = "Strongly disagree"
          2  = "Somewhat disagree"
          3  = "Somewhat agree"
          4  = "Strongly agree"
   ;
   Value Q12F
          1  = "Special education"
          2  = "General education in a self-contained classroom"
          3  = "Arts and Music"
          4  = "English/language arts"
          5  = "English as a second language"
          6  = "Foreign languages"
          7  = "Health/physical education"
          8  = "Mathematics/computer science"
          9  = "Science"
          10  = "Social sciences/social studies"
          11  = "Vocational, career, or technical education"
          12  = "Other (specify)"
   ;
   Value Q2AF
          1  = "Not available"
          2  = "Never"
          3  = "Rarely"
          4  = "Sometimes"
          5  = "Often"
   ;
   Value Q2BF
          1  = "Not available"
          2  = "Never"
          3  = "Rarely"
          4  = "Sometimes"
          5  = "Often"
   ;
   Value Q3A1F
          1  = "Not available"
          2  = "Available as needed"
          3  = "In classroom everyday"
   ;
   Value Q3A2F
          -8  = "Inapplicable"
          1  = "Never"
          2  = "Rarely"
          3  = "Sometimes"
          4  = "Often"
   ;
   Value Q3B1F
          1  = "Not available"
          2  = "Available as needed"
          3  = "In classroom everyday"
   ;
   Value Q3B2F
          -8  = "Inapplicable"
          1  = "Never"
          2  = "Rarely"
          3  = "Sometimes"
          4  = "Often"
   ;
   Value Q3C1F
          1  = "Not available"
          2  = "Available as needed"
          3  = "In classroom everyday"
   ;
   Value Q3C2F
          -8  = "Inapplicable"
          1  = "Never"
          2  = "Rarely"
          3  = "Sometimes"
          4  = "Often"
   ;
   Value Q3D1F
          1  = "Not available"
          2  = "Available as needed"
          3  = "In classroom everyday"
   ;
   Value Q3D2F
          -8  = "Inapplicable"
          1  = "Never"
          2  = "Rarely"
          3  = "Sometimes"
          4  = "Often"
   ;
   Value Q3E1F
          1  = "Not available"
          2  = "Available as needed"
          3  = "In classroom everyday"
   ;
   Value Q3E2F
          -8  = "Inapplicable"
          1  = "Never"
          2  = "Rarely"
          3  = "Sometimes"
          4  = "Often"
   ;
   Value Q3F1F
          1  = "Not available"
          2  = "Available as needed"
          3  = "In classroom everyday"
   ;
   Value Q3F2F
          -8  = "Inapplicable"
          1  = "Never"
          2  = "Rarely"
          3  = "Sometimes"
          4  = "Often"
   ;
   Value Q3G1F
          1  = "Not available"
          2  = "Available as needed"
          3  = "In classroom everyday"
   ;
   Value Q3G2F
          -8  = "Inapplicable"
          1  = "Never"
          2  = "Rarely"
          3  = "Sometimes"
          4  = "Often"
   ;
   Value Q3H1F
          1  = "Not available"
          2  = "Available as needed"
          3  = "In classroom everyday"
   ;
   Value Q3H2F
          -8  = "Inapplicable"
          1  = "Never"
          2  = "Rarely"
          3  = "Sometimes"
          4  = "Often"
   ;
   Value Q3I1F
          1  = "Not available"
          2  = "Available as needed"
          3  = "In classroom everyday"
   ;
   Value Q3I2F
          -8  = "Inapplicable"
          1  = "Never"
          2  = "Rarely"
          3  = "Sometimes"
          4  = "Often"
   ;
   Value Q4AF
          1  = "Not available"
          2  = "Never"
          3  = "Rarely"
          4  = "Sometimes"
          5  = "Often"
   ;
   Value Q4BF
          1  = "Not available"
          2  = "Never"
          3  = "Rarely"
          4  = "Sometimes"
          5  = "Often"
   ;
   Value Q4CF
          1  = "Not available"
          2  = "Never"
          3  = "Rarely"
          4  = "Sometimes"
          5  = "Often"
   ;
   Value Q4DF
          1  = "Not available"
          2  = "Never"
          3  = "Rarely"
          4  = "Sometimes"
          5  = "Often"
   ;
   Value Q4EF
          1  = "Not available"
          2  = "Never"
          3  = "Rarely"
          4  = "Sometimes"
          5  = "Often"
   ;
   Value Q5AF
          1  = "Not available"
          2  = "Never"
          3  = "Rarely"
          4  = "Sometimes"
          5  = "Often"
   ;
   Value Q5BF
          1  = "Not available"
          2  = "Never"
          3  = "Rarely"
          4  = "Sometimes"
          5  = "Often"
   ;
   Value Q5CF
          1  = "Not available"
          2  = "Never"
          3  = "Rarely"
          4  = "Sometimes"
          5  = "Often"
   ;
   Value Q5DF
          1  = "Not available"
          2  = "Never"
          3  = "Rarely"
          4  = "Sometimes"
          5  = "Often"
   ;
   Value Q6AF
          1  = "Never"
          2  = "Rarely"
          3  = "Sometimes"
          4  = "Often"
   ;
   Value Q6BF
          1  = "Never"
          2  = "Rarely"
          3  = "Sometimes"
          4  = "Often"
   ;
   Value Q6CF
          1  = "Never"
          2  = "Rarely"
          3  = "Sometimes"
          4  = "Often"
   ;
   Value Q6DF
          1  = "Never"
          2  = "Rarely"
          3  = "Sometimes"
          4  = "Often"
   ;
   Value Q6EF
          1  = "Never"
          2  = "Rarely"
          3  = "Sometimes"
          4  = "Often"
   ;
   Value Q6FF
          1  = "Never"
          2  = "Rarely"
          3  = "Sometimes"
          4  = "Often"
   ;
   Value Q6GF
          1  = "Never"
          2  = "Rarely"
          3  = "Sometimes"
          4  = "Often"
   ;
   Value Q6HF
          1  = "Never"
          2  = "Rarely"
          3  = "Sometimes"
          4  = "Often"
   ;
   Value Q6IF
          1  = "Never"
          2  = "Rarely"
          3  = "Sometimes"
          4  = "Often"
   ;
   Value Q6JF
          1  = "Never"
          2  = "Rarely"
          3  = "Sometimes"
          4  = "Often"
   ;
   Value Q6KF
          1  = "Never"
          2  = "Rarely"
          3  = "Sometimes"
          4  = "Often"
   ;
   Value Q6LF
          1  = "Never"
          2  = "Rarely"
          3  = "Sometimes"
          4  = "Often"
   ;
   Value Q6MF
          1  = "Never"
          2  = "Rarely"
          3  = "Sometimes"
          4  = "Often"
   ;
   Value Q6NF
          1  = "Never"
          2  = "Rarely"
          3  = "Sometimes"
          4  = "Often"
   ;
   Value Q6OF
          1  = "Never"
          2  = "Rarely"
          3  = "Sometimes"
          4  = "Often"
   ;
   Value Q7AF
          1  = "Not applicable"
          2  = "Never"
          3  = "Rarely"
          4  = "Sometimes"
          5  = "Often"
   ;
   Value Q7BF
          1  = "Not applicable"
          2  = "Never"
          3  = "Rarely"
          4  = "Sometimes"
          5  = "Often"
   ;
   Value Q7CF
          1  = "Not applicable"
          2  = "Never"
          3  = "Rarely"
          4  = "Sometimes"
          5  = "Often"
   ;
   Value Q7DF
          1  = "Not applicable"
          2  = "Never"
          3  = "Rarely"
          4  = "Sometimes"
          5  = "Often"
   ;
   Value Q7EF
          1  = "Not applicable"
          2  = "Never"
          3  = "Rarely"
          4  = "Sometimes"
          5  = "Often"
   ;
   Value Q7FF
          1  = "Not applicable"
          2  = "Never"
          3  = "Rarely"
          4  = "Sometimes"
          5  = "Often"
   ;
   Value Q7GF
          1  = "Not applicable"
          2  = "Never"
          3  = "Rarely"
          4  = "Sometimes"
          5  = "Often"
   ;
   Value Q7HF
          1  = "Not applicable"
          2  = "Never"
          3  = "Rarely"
          4  = "Sometimes"
          5  = "Often"
   ;
   Value Q7IF
          1  = "Not applicable"
          2  = "Never"
          3  = "Rarely"
          4  = "Sometimes"
          5  = "Often"
   ;
   Value Q7JF
          1  = "Not applicable"
          2  = "Never"
          3  = "Rarely"
          4  = "Sometimes"
          5  = "Often"
   ;
   Value Q7KF
          1  = "Not applicable"
          2  = "Never"
          3  = "Rarely"
          4  = "Sometimes"
          5  = "Often"
   ;
   Value Q7LF
          1  = "Not applicable"
          2  = "Never"
          3  = "Rarely"
          4  = "Sometimes"
          5  = "Often"
   ;
   Value Q7MF
          1  = "Not applicable"
          2  = "Never"
          3  = "Rarely"
          4  = "Sometimes"
          5  = "Often"
   ;
   Value Q7NF
          1  = "Not applicable"
          2  = "Never"
          3  = "Rarely"
          4  = "Sometimes"
          5  = "Often"
   ;
   Value Q8A1F
          1  = "Never"
          2  = "Rarely"
          3  = "Sometimes"
          4  = "Often"
   ;
   Value Q8A2F
          1  = "Never"
          2  = "Rarely"
          3  = "Sometimes"
          4  = "Often"
   ;
   Value Q8B1F
          1  = "Never"
          2  = "Rarely"
          3  = "Sometimes"
          4  = "Often"
   ;
   Value Q8B2F
          1  = "Never"
          2  = "Rarely"
          3  = "Sometimes"
          4  = "Often"
   ;
   Value Q8C1F
          1  = "Never"
          2  = "Rarely"
          3  = "Sometimes"
          4  = "Often"
   ;
   Value Q8C2F
          1  = "Never"
          2  = "Rarely"
          3  = "Sometimes"
          4  = "Often"
   ;
   Value Q8D1F
          1  = "Never"
          2  = "Rarely"
          3  = "Sometimes"
          4  = "Often"
   ;
   Value Q8D2F
          1  = "Never"
          2  = "Rarely"
          3  = "Sometimes"
          4  = "Often"
   ;
   Value Q8E1F
          1  = "Never"
          2  = "Rarely"
          3  = "Sometimes"
          4  = "Often"
   ;
   Value Q8E2F
          1  = "Never"
          2  = "Rarely"
          3  = "Sometimes"
          4  = "Often"
   ;
   Value Q8F1F
          1  = "Never"
          2  = "Rarely"
          3  = "Sometimes"
          4  = "Often"
   ;
   Value Q8F2F
          1  = "Never"
          2  = "Rarely"
          3  = "Sometimes"
          4  = "Often"
   ;
   Value Q9AF
          1  = "Not applicable"
          2  = "Not at all"
          3  = "Minor extent"
          4  = "Moderate extent"
          5  = "Major extent"
   ;
   Value Q9BF
          1  = "Not applicable"
          2  = "Not at all"
          3  = "Minor extent"
          4  = "Moderate extent"
          5  = "Major extent"
   ;
   Value Q9CF
          1  = "Not applicable"
          2  = "Not at all"
          3  = "Minor extent"
          4  = "Moderate extent"
          5  = "Major extent"
   ;
   Value Q9DF
          1  = "Not applicable"
          2  = "Not at all"
          3  = "Minor extent"
          4  = "Moderate extent"
          5  = "Major extent"
   ;
   Value Q9EF
          1  = "Not applicable"
          2  = "Not at all"
          3  = "Minor extent"
          4  = "Moderate extent"
          5  = "Major extent"
   ;
   Value Q9FF
          1  = "Not applicable"
          2  = "Not at all"
          3  = "Minor extent"
          4  = "Moderate extent"
          5  = "Major extent"
   ;
   Value SIZEF
          1  = "Less than 300"
          2  = "300 to 999"
          3  = "1,000 or more"
   ;
   Value TEACHF
          1  = "General education in self-contained classroom"
          2  = "Mathematics/computer science, science"
          3  = "Other academic subject"
          4  = "Special education, ESL"
          5  = "Other assignment"
   ;
   Value URBANF
          1  = "City"
          2  = "Suburban"
          3  = "Town"
          4  = "Rural"
   ;
   Value YEARSF
          1  = "3 or fewer years"
          2  = "4-9 years"
          3  = "10-19 years"
          4  = "20 or more years"
   ;
RUN;
